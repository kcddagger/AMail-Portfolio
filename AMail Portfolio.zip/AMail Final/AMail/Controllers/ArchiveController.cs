﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AMail.Models;
using AMail.Wrappers;
using AMailBuisnessCore.User;

namespace AMail.Controllers
{
    public class ArchiveController : Controller
    {
        // GET: Archive
        public ActionResult Vault()
        {
            MessageManager mm = new MessageManager(0, CurrentUser.GetPerson(Session).UserID, (CurrentUser.GetPerson(Session).Permission == UserPermission.Admin ? true : false));
            return View("index",mm);
        }
    }
}