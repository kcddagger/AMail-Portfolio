﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace AMail.Controllers
{
    public class AutoCompleteController : Controller
    {
        /// <summary>
        /// Called from Jquery to populate EMAIL TO box
        /// </summary>
        /// <param name="Prefix"></param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult GetUsers(string Prefix)
        {
            Models.AutoComplete ac = new Models.AutoComplete();
            //Create List<string> of users that are returned
            List<string> names = ac.GetNames(Prefix);

            //Send them back to the post for display
            return Json(names, JsonRequestBehavior.AllowGet);
        }
    }
}