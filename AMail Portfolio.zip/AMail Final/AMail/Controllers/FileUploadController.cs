﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AMail.Models;
using AMailBuisnessCore.Media;
using System.Text.RegularExpressions;

namespace AMail.Controllers
{
    public class FileUploadController : Controller
    {
        // GET: FileUpload
        [AllowAnonymous]
        public ActionResult Index()
        {
            return View();
        }

        /// <summary>
        /// tests the file for proper file extension before passing it on to the Media controls from AMailBusinessCore to be formatted for insertion into the database.
        /// The actual file upload process returns the File's intMediaID to be used by the outgoing message to indicate what file is supposed to be attached to which message.
        /// </summary>
        /// <param name="file"></param>
        /// <returns></returns>
        [AllowAnonymous]
        public ActionResult uploadFile(HttpPostedFileBase file)
        {
            string fileRegEx = @"^.+\.((pdf)|(jpg)|(jpeg)|(png)|(bmp)|(gif)|(svg))$";
            Regex regex = new Regex(fileRegEx, RegexOptions.IgnoreCase);
            string fileName;
            int mediaID;

            if (regex.IsMatch(file.FileName))
            {
                if (file.ContentLength > 0)
                {
                    Media _mediaObject = new Media(
                        Media.ToByteArray(file.InputStream)
                        , file.FileName
                        , file.ContentType);

                    fileName = file.FileName;
                    FileUpload _fileUpload = new FileUpload();
                    mediaID = _fileUpload.SaveAttachment(_mediaObject);
                    
                    return RedirectToAction("NewMessage", "message", new { message = fileName, intMediaID = mediaID });
                }
                else
                {
                    fileName = "Error: Invalid File or issue with file upload.  Please try again.";
                    return RedirectToAction("NewMessage", "message", new { message = fileName });
                }                
            }
            else
            {
                string error = "Error: Invalid file type, please upload files of the permitted types.";
                return RedirectToAction("NewMessage", "message", new { message = error });
            }                            
        }
    }
}