﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AMail.Models;
using AMail.Wrappers;
using System.Threading.Tasks;
using AMailBuisnessCore.MessageFolder;
using AMailBuisnessCore.Message;

namespace AMail.Controllers
{
    public class FolderManagerController : Controller
    {
        // GET: FolderManager
        [HttpGet]
        public ActionResult Index()
        {
            FolderManager fm = new FolderManager(CurrentUser.GetPerson(Session));
            return View();
        }
        /// <summary>
        /// Takes the input folderName and feeds it into the database SProc to create a new folder of that name attached to their UserID
        /// </summary>
        /// <param name="txtFolderName"></param>
        /// <returns></returns>
        [HttpPost]
        public async Task<ActionResult> CreateFolder(string txtFolderName)
        {
            /*Get functionality to save the folder..*/
            /*
                Not 100% sure on how I want to do this yet, but pretty sure we will use the AmailBusinessCore
             
             */
            Folder f = new Folder(txtFolderName, CurrentUser.GetPerson(Session).UserID);
            FolderManager fm = new FolderManager(CurrentUser.GetPerson(Session));
            if (await fm.CreateFolderAsync(f))
                return RedirectToAction("index", "inbox", new { FolderID = CurrentUser.GetPerson(Session).DefaultFolder });

            return View("index");
        }

        /// <summary>
        /// This action is called from the delete folder modal
        /// A user can type this into the url and it will try to delete the current folder they are in
        /// if it has messages it won't and if the folder is permanent it won't
        /// </summary>
        /// <returns></returns>
        public PartialViewResult DeleteFolderModal()
        {
            int folderIdToDelete = CurrentFolder.GetWorkingFolder(Session).ID;
            List<Folder> userFolders = CurrentFolder.GetCurrentFolderList(Session);
            Folder f = userFolders.Find(t => t.ID == folderIdToDelete);
            CurrentFolder.SetWorkingFolder(Session, f);
            return PartialView("_deleteFolder");
        }


        /// <summary>
        /// Delete a folder if a user no longer wants, the folder must be empty before this can happen
        /// Will need message count or some other type of indicator
        /// </summary>
        /// <returns></returns>
        /// 
        [HttpPost]
        public ActionResult DeleteFolder()
        {
            //Create instance of FolderManager
            FolderManager fm = new FolderManager();

            //If the delete is a success return user back to their inbox
            if (fm.RemoveFolder(CurrentFolder.GetWorkingFolder(Session)))
                return RedirectToAction("index", "inbox", new { FolderID = CurrentUser.GetPerson(Session).DefaultFolder });

            //Right now, if the action fails, we are still redirecting back to the inbox, maybe we will redirect back to here with an error in the future
            return RedirectToAction("Index", "Inbox", new { FolderID = CurrentUser.GetPerson(Session).DefaultFolder });
        }

        /// <summary>
        /// This action won't delete the message it, will simply move it to the trash
        /// Deleting messages is against business rules. 
        /// </summary>
        /// <returns></returns>
        public ActionResult DeleteMessage(int MessageID)
        {
            //TODO: Folder Manager controller delete message
            //Need to find the folder for the trash bin for the current user
            Folder f = ((Folder)CurrentFolder.GetCurrentFolderList(Session).Find(t => t.Type == FolderType.TRASH));

            //Get the message we are moving
            Message m = ((Message)CurrentFolder.GetCurrentMessageList(Session).Find(t => t.ID == MessageID));

            //Create instance of folder manager
            FolderManager fm = new FolderManager();
            fm.DeleteMessage(m, f, CurrentUser.GetPerson(Session));
            return RedirectToAction("index", "inbox", new { FolderID = CurrentFolder.GetWorkingFolder(Session).ID });
        }

        /// <summary>
        /// This action won't delete the message it will set the status to Archive, and remove it from the user's View.
        /// Deleting messages is against business rules. 
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        public ActionResult ArchiveMessage(FormCollection archive)
        {
            //TODO: Folder Manager controller archive message

            //Get the messageID we are moving
            int messageID = Int32.Parse(archive["messageID"].ToString());
            int userID = CurrentUser.GetPerson(Session).UserID;

            //Create instance of folder manager
            FolderManager fm = new FolderManager();
            fm.ArchiveMessage(messageID, userID);
            return RedirectToAction("index", "inbox", new { FolderID = CurrentFolder.GetWorkingFolder(Session).ID });
        }

        [HttpPost]
        public ActionResult UnarchiveMessage(FormCollection unarchive)
        {
            int messageID = Int32.Parse(unarchive["messageID"].ToString());
            int userID = Int32.Parse(unarchive["userID"].ToString());

            //Create instance of folder manager
            FolderManager fm = new FolderManager();
            fm.ArchiveMessage(messageID, userID);

            return RedirectToAction("Vault", "archive");
        }

        public ActionResult UnReadMessage(int messageID)
        {
            //Create instance of FolderManager
            FolderManager fm = new FolderManager();
            fm.UnReadMessage(messageID, CurrentUser.GetPerson(Session).UserID);

            return RedirectToAction("index", "inbox", new { FolderID = CurrentFolder.GetWorkingFolder(Session).ID });
        }

        /// <summary>
        /// Called from jquery
        /// </summary>
        /// <param name="messageIDs"></param>
        /// <returns></returns>
        [HttpPost]
        public ActionResult CheckboxIDS(string messageIDs)
        {
            Session["MessageIDS"] = messageIDs;
            return PartialView("_moveMessage");
        }

        /// <summary>
        /// Called from _moveMessage View
        /// </summary>
        /// <returns></returns>

        public ActionResult MoveMessage(int folderToMoveTo, int folderToMoveFrom)
        {
            MessageManager mm = new MessageManager(folderToMoveFrom, CurrentUser.GetPerson(Session).UserID);
            mm.MoveMessages(folderToMoveTo, folderToMoveFrom, Session["MessageIDS"].ToString(), CurrentUser.GetPerson(Session).UserID);

            return RedirectToAction("index", "inbox", new { FolderID = CurrentFolder.GetWorkingFolder(Session).ID });
        }
    }
}