﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AMail.Wrappers;
using AMail.Models;

namespace AMail.Controllers
{
    public class HomeController : Controller
    {
        [AllowAnonymous]
        public ActionResult Index()
        {
            return View();
        }

        [AllowAnonymous]
        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";
            return View();
        }

        /// <summary>
        /// Calls the user's account details.
        /// message is used to pass back positive or negative results of the user's attempt to change their details.
        /// Later on Message can be used to pass on messages to specific users when they log in and check their settings.  Password update reminders and the like.
        /// The Viewbag.Message will hold the message for display then feed it into the message location on the User Account Page.
        /// </summary>
        /// <param name="message"></param>
        /// <returns></returns>
        public ActionResult Account(string message = "")
        {
            Account _account = new Account(CurrentUser.GetPerson(Session));
            ViewBag.Message = message;
            return View(_account);
        }        

        /// <summary>
        /// pulls in the information from the password change form and validates it 
        /// before either sending back an error message or calling the PWManage model to pass the information back up 
        /// to the server to officially change the previous password in the database.
        /// </summary>
        /// <param name="pwChange"></param>
        /// <returns>RedirectToAction w/ message</returns>
        [HttpPost]
        public ActionResult ChangePassword(FormCollection pwChange)
        {
            int UserID = CurrentUser.GetPerson(Session).UserID;
            string newPW = pwChange["txtPassword"];
            string newConfPW = pwChange["txtConfPassword"];

            if (newPW != newConfPW)
            {
                string error = "There was an error changing your password.  The chosen password did not match the confirmation.  Try again?";
                return RedirectToAction("account", "home", new { message = error });
            }
            else
            {
                new PWManage(UserID, newPW, newConfPW);
                string success = "Password change successful.  Please use your new password from now on.";
                return RedirectToAction("account", "home", new { message = success });
            }
        }
    }
}