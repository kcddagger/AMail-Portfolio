﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AMail.Models;
using AMail.Wrappers;
using AMailBuisnessCore.User;
using AMailBuisnessCore.Message;
using AMailBuisnessCore.MessageFolder;

namespace AMail.Controllers
{
    public class InboxController : Controller
    {
        // GET: Inbox
        [HttpGet]
        public ActionResult Index()
        {
            /// <summary>
            /// Try: Attempts to set the user's FolderList and starting folder based on current Session variables
            /// Catch: Force sets the user's starting folder using a direct query of the Get Request parsed into the FolderID format. 
            /// </summary>
            try
            {
                int folderID = Int32.Parse(Request.QueryString["FolderID"].ToString());
                //Set the current working folder, pretty much right now this is just an id
                CurrentFolder.SetWorkingFolder(Session, CurrentFolder.GetCurrentFolderList(Session).Find(t => t.ID == folderID));
            }
            catch (Exception)
            {
                CurrentFolder.SetWorkingFolder(Session, new Folder(Int32.Parse(Request.QueryString["FolderID"].ToString())));
            }

            
            return View();
        }
        
        /// <summary>
        /// Takes the WorkingFolderID (Active folder), and UserID passing in the associated message data from MessageManager Model.
        /// </summary>
        /// <param name="FolderID"></param>
        /// <param name="FolderName"></param>
        /// <returns></returns>
        public PartialViewResult _Messages(int FolderID = 0)
        {
            int userID = CurrentUser.GetPerson(Session).UserID;
            MessageManager mm = new MessageManager(FolderID, userID);
            
            return PartialView(mm);            
        }        
    }
}