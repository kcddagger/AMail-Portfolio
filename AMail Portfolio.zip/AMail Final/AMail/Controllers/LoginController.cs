﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Threading.Tasks;
using AMailBuisnessCore.User;
using AMail.Wrappers;
using AMail.Models;

namespace AMail.Controllers
{
    public class LoginController : Controller
    {
        private IUser _currentUser;
        Login _login = new Login();

        // GET: Login
        [AllowAnonymous]
//        [HttpPost] <Allows only HttpPost requests to access this action.
        public ActionResult Index()
        {
            if (Request.HttpMethod == "POST")
            {

            }
            return View();
        }

        /// <summary>
        /// Action to call when logging in with a GUID
        /// Right now this is only occuring when the user registers
        /// </summary>
        /// <returns></returns>
        [AllowAnonymous]
        public ActionResult LoginWithGUID()
        {
            //Since this is a different way of loggin in, we don't want users
            //trying to access this method unless a GUID has been assigned.
            //So we check for it, if it's not there, just redirect them back to the home page
            
            /* If you're going to redirect them if they don't have a valid GUID, 
             * why not redirect them to the registration page if its clear that the GUID Doesn't exist?
             */
            if (!CurrentUser.HasGUID(Session))
                return RedirectToAction("index", "home");

            _currentUser = _login.Authenticate(CurrentUser.GetGUID(Session));
            return CheckUserForNull();
        }

        /// <summary>
        /// Standard way of loggin a user in, this is through the site. 
        /// </summary>
        /// <param name="UserName"></param>
        /// <param name="Password"></param>
        /// <returns></returns>
        [AllowAnonymous]
        [HttpPost]
        public async Task<ActionResult> LoginAsync(string UserName, string Password)
        {
            _currentUser = await _login.AuthenticateAsync(UserName, Password);
            return CheckUserForNull();
        }

        /// <summary>
        /// Method to return the proper view depending on the current status of the _currentUser object
        /// </summary>
        /// <returns></returns>
        private ActionResult CheckUserForNull()
        {
            if (_currentUser != null)
            {
                CurrentUser.SetUser(Session, _currentUser);//Put current user into session
                //redirect to inbox and post back the current user default folder id, so inbox INDEX action can read that and display the proper messages in the given folder
                return RedirectToAction("index", "inbox", new { FolderID = _currentUser.DefaultFolder });
            }
            //Something went wrong, return user back to login screen
            return RedirectToAction("index", "login", new { val = "authfailed" });
        }

        /// <summary>
        /// Simple Action to log the current user out
        /// </summary>
        /// <returns></returns>
        /* Is there a Timeout function that forces this action somewhere? */
        [HttpGet]
        public ActionResult Logout()
        {

            AMail.Wrappers.CurrentUser.SetUser(Session, null);
            AMail.Wrappers.CurrentUser.Logout(HttpContext.Session);
            Session["currentFolder"] = null;
            Session.Remove("currentFolder");
            Session["currentFolderList"] = null;
            Session.Remove("currentFolderList");

            CurrentUser.SetUser(Session, null);
            CurrentUser.Logout(HttpContext.Session);
            CurrentFolder.Logout(HttpContext.Session);


            return RedirectToAction("index", "home");
        }
    }
}