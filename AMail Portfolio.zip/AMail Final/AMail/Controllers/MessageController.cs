﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AMail.Wrappers;
using AMail.Models;
using AMailBuisnessCore.Media;

namespace AMail.Controllers
{
    public class MessageController : Controller
    {        
        // GET: Message
        public ActionResult Index()
        {
            try
            {
                int messageID = Int32.Parse(Request.QueryString["MessageID"].ToString());
            }
            catch (Exception)
            {

                //throw;
            }
            return View();
        }

        /// <summary>
        /// Pulls the selected message from the server by MessageID.
        /// Forwards the message data to the ReadMail View for formatting and Display
        /// </summary>
        /// <param name="MessageID"></param>
        /// <returns></returns>
        public ActionResult ReadMail(int MessageID = 0)
        {
            int userID = CurrentUser.GetPerson(Session).UserID;
            DisplayMessage dm = new DisplayMessage(MessageID, userID);
            
            return View(dm);
        }

        /// <summary>
        /// Allow user to download attachment
        /// </summary>
        /// <param name="MessageID">ID of the current message</param>
        /// <param name="mediaID">ID of the media we need to prepare for user download</param>
        /// <returns></returns>
        public FileContentResult Download(int MessageID, int mediaID)
        {
            DisplayMessage dm = new DisplayMessage(MessageID, CurrentUser.GetPerson(Session).UserID);
            Media m = dm.UserMessage.MyAttachments.ToList.Find(t => mediaID == t.ID);
            return File(m.Content, m.ContentType, m.Name + "." + m.Extension);
        }

        /// <summary>
        /// Generate a preview of the attachment
        /// </summary>
        /// <param name="MessageID">Current message we are working with</param>
        /// <param name="mediaID">id of the media we need to display</param>
        /// <returns></returns>
        public ActionResult Preview(int MessageID, int mediaID)
        {
            DisplayMessage dm = new DisplayMessage(MessageID, CurrentUser.GetPerson(Session).UserID);
            Media m = dm.UserMessage.MyAttachments.ToList.Find(t => mediaID == t.ID);
            return File(m.Content, m.ContentType);
        }

        /// <summary>
        /// Takes the MessageID of the message that is being replied to and uses the previous message's information to set up the form for a ReplyMail
        /// </summary>
        /// <param name="MessageID"></param>
        /// <returns></returns>
        public ActionResult ReplyMail(int MessageID = 0)
        {
            int userID = CurrentUser.GetPerson(Session).UserID;
            DisplayMessage dm = new DisplayMessage(MessageID, userID);            

            return View(dm);
        }

        /// <summary>
        /// Takes the message (a FileName that was uploaded for attachment) and nullable intMediaID variables to 
        /// set up a new message for the user to fill out and send.
        /// </summary>
        /// <param name="message"></param>
        /// <param name="intMediaID"></param>
        /// <returns></returns>
        public ActionResult NewMessage(string message, int? intMediaID)
        {
            string mediaID;
            if (intMediaID == null)
            {
                mediaID = "";
            }
            else
            {
                mediaID = intMediaID.ToString();
            }

            if (message == null)
            {
                message = "";
            }            
            else if (message.StartsWith("Error: "))
            {
                ViewBag.ErrorMessage = message;
            }
            else
            {
                ViewBag.ErrorMessage = "";
                ViewBag.FileMessage = message;
                ViewBag.MediaID = mediaID;
            }
            return View();           
        }

        /// <summary>
        /// Collects the results of the NewMail form to process into a new message for an intended user with or without a file attachment.
        /// Passes the collected and formatted data to the NewMessage Model to input into the database before redirecting the user back to their Inbox folder
        /// </summary>
        /// <param name="mail"></param>
        /// <returns></returns>
        [HttpPost]
        public ActionResult MailSent(FormCollection mail)
        {
            int userID = CurrentUser.GetPerson(Session).UserID;            
            string recipient = mail["recipient"];
            string subject = mail["subject"];
            string body = mail["body"];
            int? mediaID;
            if (mail["mediaID"] == "" || mail["mediaID"] == null)
            {
                mediaID = null;
            }
            else
	        {
                mediaID = Int32.Parse(mail["mediaID"]);
            }
            new NewMessage(userID, recipient, subject, body, mediaID);
            
            return RedirectToAction("index", "inbox", new { FolderID = CurrentUser.GetPerson(Session).DefaultFolder });
        }        
    }
}