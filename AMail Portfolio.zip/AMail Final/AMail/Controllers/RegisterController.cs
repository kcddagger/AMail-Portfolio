﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AMail.Models;
using AMail.Wrappers;

namespace AMail.Controllers
{
    public class RegisterController : Controller
    {
        // GET: Register
        [AllowAnonymous]
        [HttpGet]
        public ActionResult Index(string error)
        {
            return View();
        }


        /// <summary>
        /// Action that is called for when a user is registering on the site
        /// </summary>
        /// <param name="FirstName"></param>
        /// <param name="LastName"></param>
        /// <param name="UserName"></param>
        /// <param name="Password"></param>
        /// <param name="viewModel"></param>
        /// <param name="DateOfBirth"></param>
        /// <returns></returns>
        [AllowAnonymous]
        [HttpPost]
        public ActionResult RegisterUser(string FirstName, string LastName, string UserName, string Password, Models.Register viewModel, DateTime? DateOfBirth)
        {
            if (ModelState.IsValid)
            {
                string emailAddress = UserName + "@amail.com";
                Register r = new Register(FirstName, LastName, UserName, Password, DateOfBirth, emailAddress);
                try
                {
                    //Check so a user can't keep hitting refresh and create multiple accounts
                    if (!CurrentUser.HasGUID(Session))
                    {
                        if (r.Save())
                        {
                            CurrentUser.SetGUID(Session,r.GUID);//Set the GUID that is assigned to the user into Session
                            return View("thankyou", viewModel);//Return a thank you page
                        }
                    }
                    else
                    {
                        //We need to notify the user that their account is already registered
                        //Return them back to the index of this controller along with an error in the query string
                        return RedirectToAction("index", "register", new { error = "registered" });
                    }
                }
                //Variable e declared for Exception Class.  What is being done with it?  Throwing it?
                catch(Exception e)
                {

                }
            }
            return View("index");
        }

        [HttpGet]
        [AllowAnonymous]
        [ChildActionOnly]
        public ActionResult Thankyou()
        {
            return View();
        }
    }
}