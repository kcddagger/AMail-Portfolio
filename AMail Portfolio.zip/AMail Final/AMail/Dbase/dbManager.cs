﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Threading.Tasks;

namespace AMail.Dbase
{
    public class dbManager
    {
        private string connectionString = "Data Source=192.168.4.18\\acs2014; User ID=sa; Password=alk0t@im@g3; Initial Catalog=amail;";
        private SqlConnection sqlConnection;
        private SqlCommand sqlCommand;

        private ArrayList _returnValue = new ArrayList();

        public dbManager()
        {

        }

        //Create and open a SqlConneciton
        private void OpenConnection()
        {
            if (sqlConnection == null)
            {
                sqlConnection = new SqlConnection(connectionString);
                sqlConnection.Open();
                return;
            }

            if(sqlConnection.State == ConnectionState.Closed)
            {
                sqlConnection.Dispose();
                sqlConnection = new SqlConnection(connectionString);
                sqlConnection.Open();
                return;
            }

            sqlConnection = new SqlConnection(connectionString);
            sqlConnection.Open();
            return;
        }

        /// <summary>
        /// Close and dispose of the sql connection
        /// </summary>
        private void CloseConnection()
        {
            try
            {
                sqlConnection.Close();
                sqlConnection.Dispose();
            }
            catch(SqlException connectionException)
            {
                //TODO:Write to log
                //Create a simple but effection logging system that will write to a log file on the server
            }
        }

        /// <summary>
        /// Create simple command passing in a store proc to execute
        /// </summary>
        /// <param name="sqlProc"></param>
        private void CreateProcCommand(string sqlProc)
        {
            sqlCommand = new SqlCommand(sqlProc, sqlConnection);
            sqlCommand.Connection = sqlConnection;
        }

        /// <summary>
        /// Create a simple command passing in a stored proc with parameters to execute
        /// </summary>
        /// <param name="sqlProc"></param>
        /// <param name="parameters"></param>
        private void CreateProcCommand(string sqlProc, List<SqlParameter> parameters)
        {
            sqlCommand = new SqlCommand(sqlProc);
            sqlCommand.CommandType = CommandType.StoredProcedure;
            sqlCommand.Connection = sqlConnection;
            foreach (SqlParameter p in parameters)
            {
                sqlCommand.Parameters.Add(new SqlParameter(p.ParameterName, p.Value));
            }
        }

        /// <summary>
        /// Get data from dbase into a DataTable
        /// </summary>
        /// <param name="strProc"></param>
        /// <returns></returns>
        protected DataTable GetDataTableProc(string strProc)
        {
            CreateProcCommand(strProc);
            OpenConnection();
            using (SqlDataAdapter da = new SqlDataAdapter(sqlCommand))
            {
                DataTable dt = new DataTable();
                da.Fill(dt);
                CloseConnection();
                return dt;
            }            
        }

        /// <summary>
        /// Get data from dbase into a datatable using parameters for the select
        /// </summary>
        /// <param name="strProc"></param>
        /// <param name="parameters"></param>
        /// <returns></returns>
        protected DataTable GetDataTableProc(string strProc, List<SqlParameter> parameters)
        {
            OpenConnection();
            CreateProcCommand(strProc,parameters);
            using (SqlDataAdapter da = new SqlDataAdapter(sqlCommand))
            {
                DataTable dt = new DataTable();
                da.Fill(dt);
                CloseConnection();
                return dt;
            }
        }

        /// <summary>
        /// Get data from dbase asyncronously using parameters
        /// </summary>
        /// <param name="strProc"></param>
        /// <param name="parameters"></param>
        /// <returns></returns>
        protected async Task<DataTable> GetDataTableProcAsync(string strProc, List<SqlParameter> parameters)
        {
            OpenConnection();
            CreateProcCommand(strProc, parameters);
            
            using (SqlDataAdapter da = new SqlDataAdapter(sqlCommand))
            {
                
                DataTable dt = new DataTable();
                await Task.Run(() => { da.Fill(dt); });
                CloseConnection();
                return dt;
            }
        }

        /// <summary>
        /// Insert some data into the db asyncronously
        /// </summary>
        /// <param name="strProc"></param>
        /// <param name="parameters"></param>
        /// <returns></returns>
        protected async Task<Boolean> InsertDataProcAsync(string strProc, List<SqlParameter> parameters)
        {
            OpenConnection();
            CreateProcCommand(strProc, parameters);

            try
            {
                await sqlCommand.ExecuteNonQueryAsync();
                return true;
            }
            catch (SqlException) { return false; }

        }

        /// <summary>
        /// Insert data into the db with parameters, if there is a return value it will be
        /// set in the returnValue array list
        /// </summary>
        /// <param name="strProc"></param>
        /// <param name="parameters"></param>
        /// <returns></returns>
        protected bool InsertDataProc(string strProc, List<SqlParameter> parameters)
        {
            OpenConnection();
            CreateProcCommand(strProc, parameters);
            string GUID = string.Empty;
            try
            {
                _returnValue.Add(sqlCommand.ExecuteScalar());//ExecuteNonQuery();
                //sqlCommand.ExecuteNonQuery();
                CloseConnection();
                return true;

            }
            catch (SqlException e) { return false; }
        }

        /// <summary>
        /// Delete data from db
        /// This method doesn not have a return type, the return value will be handed back from the stored proc
        /// with either a true or false obviously for success or failure
        /// You must look in the returnValue property for this value
        /// </summary>
        /// <param name="strProc"></param>
        /// <param name="parameters"></param>
        protected void DeleteDataProc(string strProc, List<SqlParameter> parameters)
        {
            OpenConnection();
            CreateProcCommand(strProc, parameters);
            try
            {
                _returnValue.Add(sqlCommand.ExecuteScalar());
                CloseConnection();
                

            }
            catch (SqlException e) { return; }
        }

        /// <summary>
        /// Update data in db
        /// This method doesn not have a return type, the return value will be handed back from the stored proc
        /// with either a true or false obviously for success or failure
        /// You must look in the returnValue property for this value
        /// </summary>
        /// <param name="strProc"></param>
        /// <param name="parameters"></param>
        protected void UpdateDataProc(string strProc, List<SqlParameter> parameters)
        {
            OpenConnection();
            CreateProcCommand(strProc, parameters);
            try
            {
                _returnValue.Add(sqlCommand.ExecuteScalar());
                CloseConnection();
            }
            catch (SqlException e) {
                CloseConnection();
            }
        }        

        /// <summary>
        /// This can be populated if and when a insert query needs to return a result
        /// </summary>
        protected object ReturnValue
        {
            get => _returnValue[0];
        }

    }
}