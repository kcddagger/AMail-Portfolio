﻿using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

namespace AMail.Filters
{
    public class SecurityCheck : AuthorizeAttribute
    {
        /// <summary>
        /// Run a security check here to see if the user is logged on
        /// 
        /// Other checks can be ran here as well.
        /// </summary>
        /// <param name="httpContext"></param>
        /// <returns></returns>
        protected override bool AuthorizeCore(HttpContextBase httpContext)
        {
            try
            {
                if(Wrappers.CurrentUser.IsValid(httpContext.Session))
                {
                    return true;
                }
            }
            catch(System.Exception)
            {
                return false;
            }

            return false;
        }

        protected override void HandleUnauthorizedRequest(AuthorizationContext filterContext)
        {
            filterContext.Result = new RedirectToRouteResult(new RouteValueDictionary(new { controller = "login", action = "index" }));

        }
    }
}