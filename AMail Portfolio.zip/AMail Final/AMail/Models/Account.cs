﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using AMailBuisnessCore.User;

namespace AMail.Models
{
    public class Account
    {
        public Account(Person user)
        {
            FirstName = user.FirstName;
            LastName = user.LastName;
            UserName = user.UserName;
            Password = user.PassWord;
            LoginCount = user.LoginCount;
            LastLogin = user.LastLogin;
            userGUID = user.GUID;
        }

        [Display(Name = "First Name")]
        public string FirstName { get; set; }

        [Display(Name = "Last Name")]
        public string LastName { get; set; }

        [Display(Name = "User Name")]
        public string UserName { get; set; }

        public string Password { get; set; }

        [Display(Name = "Login Counter")]
        public int LoginCount { get; set; }

        [Display(Name = "Last Login")]
        public DateTime LastLogin { get; set; }

        public string userGUID { get; set; }
    }
}