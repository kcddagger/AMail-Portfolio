﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace AMail.Models
{
    public class AutoComplete : Dbase.dbManager
    {

        /// <summary>
        /// Get a list of names based on a search term
        /// </summary>
        /// <param name="searchTerm"></param>
        /// <returns></returns>
        public List<string> GetNames(string searchTerm)
        {
            List<string> matchedNames = new List<string>();
            List<SqlParameter> parameters = new List<SqlParameter>();
            parameters.Add(new SqlParameter("@vcSearchTerm", searchTerm));
            System.Data.DataTable dt = base.GetDataTableProc("Person_S_BySearchTerm", parameters);
            System.Data.DataView dv = new System.Data.DataView(dt);

            //Loop the view and add them to the list and return
            foreach(System.Data.DataRowView drv in dv)
            {
                matchedNames.Add(drv["Name"].ToString());
            }


            return matchedNames;
        }


    }
}