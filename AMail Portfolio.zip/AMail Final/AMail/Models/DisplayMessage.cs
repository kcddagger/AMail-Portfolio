﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using AMailBuisnessCore.Message;
using System.ComponentModel.DataAnnotations;
using System.Data;
using AMail.Dbase;
using System.Data.SqlClient;

namespace AMail.Models
{
    public class DisplayMessage : dbManager
    {
        private Message mailMessage;
        private int intMessageID = -1;
        private int intUserID = -1;

        /// <summary>
        /// A message ID and User ID will always be required
        /// Messages can be attached to multiple users, but everything that is the message is attached to the message ID
        /// </summary>
        /// <param name="messageID"></param>
        /// <param name="userID"></param>
        public DisplayMessage(int messageID, int userID)
        {
            intMessageID = messageID;
            intUserID = userID;

            //Get and load up message
            GetMail();
        }

        /// <summary>
        /// Get the message details for the messageID passed in
        /// If a valid message is found, ValidMessage will return true.
        /// </summary>
        /// <returns>mailMessage object of Message type</returns>
        private Message GetMail()
        {
            List<SqlParameter> parameters = new List<SqlParameter>();
            parameters.Add(new SqlParameter("@intUserID", intUserID));
            parameters.Add(new SqlParameter("@intMessageID", intMessageID));
            DataTable dt = GetDataTableProc("MessageByIDByUser", parameters);
            DataView dv = new DataView(dt);

            //Check to see if a valid message was returned
            
            if (dv.Count > 0)
            {               
                DataRowView message = dv[0];
                mailMessage = new Message(Int32.Parse(message["intID"].ToString())
                    , (message["strMessageSubject"] == DBNull.Value ? "" : message["strMessageSubject"].ToString())
                    , message["strMessageBody"].ToString(), Int32.Parse(message["intAuthorID"].ToString())
                    , Int32.Parse(message["intRecipientID"].ToString()), Int32.Parse(message["intStatus"].ToString())
                    , message["strGUID"].ToString(), message["strAuthoruserName"].ToString()
                    , message["strAuthorFullName"].ToString(), message["strRecipientFullName"].ToString()
                    , message["strRecipientUserName"].ToString(), DateTime.Parse(message["dtSent"].ToString())
                    , (message["dtArchived"] == DBNull.Value ? (DateTime?)null : DateTime.Parse(message["dtArchived"].ToString())));

                return mailMessage;

            }
            else
            {
                return null;
            }
        }

        /// <summary>
        /// Indicates if message valid
        /// </summary>
        /// <return>boolean</return>
        // Where/How is this being called?
        public bool ValidMessage
        {
            get
            {
                if (mailMessage != null)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

        /// <summary>
        /// The current message.
        /// UserMessage is the access to the type Message
        /// </summary>
        public Message UserMessage
        {
            get => mailMessage;
        }
    }
}