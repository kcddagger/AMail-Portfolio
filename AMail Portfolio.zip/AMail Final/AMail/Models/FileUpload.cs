﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using AMail.Dbase;
using System.Data;
using AMailBuisnessCore.Media;
using System.Data.SqlClient;

namespace AMail.Models
{
    public class FileUpload : dbManager
    {
        Media attachment;

        /// <summary>
        /// Takes the file being passed in of the Media type and breaking out its component properties prepares the file to be uploaded into the database.
        /// The return SHOULD be the intMediaID of the file once the record has been created in the table.
        /// A return that causes an error indicates that the record did not create properly.
        /// </summary>
        /// <param name="_attachment"></param>
        /// <returns></returns>
        public int SaveAttachment(Media _attachment)
        {
            List<SqlParameter> parameters = new List<SqlParameter>();
            parameters.Add(new SqlParameter("@strName", _attachment.Name));
            parameters.Add(new SqlParameter("@strContentType", _attachment.ContentType));
            parameters.Add(new SqlParameter("@strExtension", _attachment.Extension));
            parameters.Add(new SqlParameter("@binMedia", _attachment.Content));

            InsertDataProc("temp_uploadFileSave", parameters);
            return (int)base.ReturnValue;
        }

        /// <summary>
        /// Retrieves the file from the database using the message and media IDs passed in from the link in the message.
        /// converts the varbinary type back into byte array.
        /// </summary>
        /// <param name="intMediaID"></param>
        /// <param name="intMessageID"></param>
        /// <returns></returns>
        public Media GetAttachment(int intMessageID, int intMediaID)
        {            
            List<SqlParameter> parameters = new List<SqlParameter>();
            parameters.Add(new SqlParameter("@intMessageID", intMessageID));
            parameters.Add(new SqlParameter("@intMediaID", intMediaID));
            DataTable dt = GetDataTableProc("GetAttachment", parameters);
            DataView dv = new DataView(dt);

            if (dv.Count > 0)
            {
                DataRowView attach = dv[0];
                attachment = new Media(Int32.Parse(attach["ID"].ToString())
                    , attach["Name"].ToString(), attach["Content"] as byte[]
                    , attach["GUID"].ToString(), attach["ContentType"].ToString()
                    , attach["Extension"].ToString(), DateTime.Parse(attach["Created"].ToString()));

                return attachment;
            }
            else
            {
                return null;
            }
            
        }

        /// <summary>
        /// Checks to see if returned data is a valid Media item.
        /// </summary>
        public bool ValidAttachment
        {
            get
            {
                if (attachment != null)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

        public Media UserAttach
        {
            get => attachment;
        }
    }
}