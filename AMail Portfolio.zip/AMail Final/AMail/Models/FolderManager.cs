﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using AMailBuisnessCore.User;
using AMailBuisnessCore.MessageFolder;
using System.Data;
using AMail.Dbase;
using AMailBuisnessCore.Message;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace AMail.Models
{
    public class FolderManager : dbManager
    {
        public FolderManager() { }
        public FolderManager(IUser p)
        {
            UserID = p.UserID;
        }

        /// <summary>
        /// Create and save a new folder for the given user/owner
        /// </summary>
        /// <param name="newFolder"></param>
        /// <returns></returns>
        public async Task<bool> CreateFolderAsync(Folder newFolder)
        {
            List<SqlParameter> parameters = new List<SqlParameter>();
            parameters.Add(new SqlParameter("@strFolderName", newFolder.Name));
            parameters.Add(new SqlParameter("@intOwnerID", newFolder.OwnerID));
            parameters.Add(new SqlParameter("@intParentFolderID", newFolder.ParentFolderID));

            return await base.InsertDataProcAsync("Folder_IU", parameters);
        }

        /// <summary>
        /// Call the DB to remove the incoming folder
        /// </summary>
        /// <param name="folder"></param>
        /// <returns></returns>
        public Boolean RemoveFolder(Folder folder)
        {
            List<SqlParameter> parameters = new List<SqlParameter>();
            parameters.Add(new SqlParameter("@intFolderID", folder.ID));
            parameters.Add(new SqlParameter("@intUserID", folder.OwnerID));
            base.DeleteDataProc("FolderByUser_Delete", parameters);

            return (Boolean)base.ReturnValue;

        }

        //TODO:Folder Manager Model DELETE message
        /// <summary>
        /// Take selected message(s) and move to Trash Folder
        /// </summary>
        /// <param name="m"></param>
        /// <param name="f"></param>
        /// <param name="i"></param>
        /// <returns></returns>
        public void DeleteMessage(Message m, Folder f, IUser i)
        {
            List<SqlParameter> parameters = new List<SqlParameter>();
            parameters.Add(new SqlParameter("@intMessageID", m.ID));
            parameters.Add(new SqlParameter("@intFolderID", f.ID));
            parameters.Add(new SqlParameter("@intUserID", i.UserID));

            base.UpdateDataProc("Message_Trash", parameters);
        }

        /// <summary>
        /// Take selected message and change the status to Archived
        /// </summary>
        /// <param name="mID"></param>
        /// <param name="i"></param>
        /// <return></return>
               
        [HttpPost]
        public void ArchiveMessage(int mID, int uID)
        {
            List<SqlParameter> parameters = new List<SqlParameter>();
            parameters.Add(new SqlParameter("@intMessageID", mID));
            parameters.Add(new SqlParameter("@intUserID", uID));

            UpdateDataProc("Message_Archive", parameters);
        }

        /// <summary>
        /// Fill the USER folder LIST
        /// </summary>
        /// <returns></returns>
        private List<Folder> GetFolders()
        {
            //Create emptry folder list
            _userFolders = new List<Folder>();
            //Get a list of folders
            List<SqlParameter> parameters = new List<SqlParameter>();
            parameters.Add(new SqlParameter("@intUserID", UserID));
            DataTable dt = GetDataTableProc("FolderByUserID", parameters);
            DataView userFolder = new DataView(dt);
            foreach(DataRowView folder in userFolder)
            {
                _userFolders.Add(new Folder(Int32.Parse(folder["intID"].ToString())
                                                        , folder["strName"].ToString()
                                                        , Int32.Parse(folder["MessageCount"].ToString())
                                                        , Int32.Parse(folder["intUserID"].ToString())
                                                        , (folder["intParentID"] == DBNull.Value ? -1 : Int32.Parse(folder["intParentID"].ToString()))
                                                        , Boolean.Parse(folder["bitPermanent"].ToString())
                                                        , (FolderType)Int32.Parse(folder["intType"].ToString())
                                                        , DateTime.Parse(folder["dtCreated"].ToString())));
            }

            return _userFolders;
        }

        /// <summary>
        /// Get the users folders
        /// if the user folder list is null, then a call is made to getfolders and fill the list
        /// </summary>
        List<Folder> _userFolders;
        public List<Folder> UserFolders
        {
            get { return _userFolders ?? GetFolders(); }
        }

        /// <summary>
        /// USER ID of the current user
        /// </summary>
        public int UserID
        {
            get; protected set;
        }

        [HttpPost]
        public void UnReadMessage(int mID, int userID)
        {
            List<SqlParameter> parameters = new List<SqlParameter>();
            parameters.Add(new SqlParameter("@intMessageID", mID));
            parameters.Add(new SqlParameter("@intUserID", userID));

            UpdateDataProc("Message_UnRead", parameters);
        }
    }
}