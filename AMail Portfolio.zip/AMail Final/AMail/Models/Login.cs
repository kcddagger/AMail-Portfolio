﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Threading.Tasks;
using AMail.Dbase;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;
using AMailBuisnessCore.User;

namespace AMail.Models
{
    public class Login : dbManager
    {
        private DataTable _userDataTable;

        public Login()
        {
        }

        /// <summary>
        /// Authenticate the user Asyncronously
        /// </summary>
        /// <param name="strUserName"></param>
        /// <param name="strPassword"></param>
        /// <returns></returns>
        public async Task<IUser> AuthenticateAsync(string strUserName, string strPassword)
        {

            List<SqlParameter> parameters = new List<SqlParameter>();
            parameters.Add(new SqlParameter("@strUserName", strUserName));
            parameters.Add(new SqlParameter("@strPassword", strPassword));
            _userDataTable = await GetDataTableProcAsync("AuthenticateLogin", parameters);
            return AssemlbleUserObject();
        }

        /// <summary>
        /// This is our authentication method when registering
        /// </summary>
        /// <param name="GUID"></param>
        /// <returns></returns>
        public IUser Authenticate(string GUID)
        {
            List<SqlParameter> parameters = new List<SqlParameter>();
            parameters.Add(new SqlParameter("@guid", GUID));
            _userDataTable = GetDataTableProc("AuthenticateLogin_GUID", parameters);
            return AssemlbleUserObject();

        }

        /// <summary>
        /// Method to assemble the user object that gets passed back to the controller and eventually stored in session
        /// </summary>
        /// <returns>IUser, or NULL on failure</returns>
        private IUser AssemlbleUserObject()
        {
            DataView userDV = new DataView(_userDataTable);
            //Make sure we have data from the DB, if not return a null Iuser
            if (userDV.Count < 1)
                return null;

            DataRowView user = userDV[0];
            IUser _currentUser;
            switch (Int32.Parse(user["intUserTypeID"].ToString()))
            {
                //Create a standard user
                case (int)UserPermission.Standard:
                    _currentUser = new StandardUser(Int32.Parse(user["intUserID"].ToString())
                                                               , user["strFirstName"].ToString(), user["strLastName"].ToString(), DateTime.Parse(user["dtDateOfBirth"].ToString())
                                                               , user["strUserName"].ToString(), user["strPassword"].ToString(), user["strGUID"].ToString(), Int32.Parse(user["DefaultFolderID"].ToString())
                                                               , DateTime.Parse(user["dtLastLogin"].ToString()), Int32.Parse(user["intLoginCount"].ToString()));
                    break;

                //Create an admin user
                case (int)UserPermission.Admin:
                    _currentUser = new AdminUser(Int32.Parse(user["intUserID"].ToString())
                                        , user["strFirstName"].ToString(), user["strLastName"].ToString(), DateTime.Parse(user["dtDateOfBirth"].ToString())
                                        , user["strUserName"].ToString(), user["strPassword"].ToString(), user["strGUID"].ToString(), Int32.Parse(user["DefaultFolderID"].ToString())
                                        , DateTime.Parse(user["dtLastLogin"].ToString()), Int32.Parse(user["intLoginCount"].ToString()));
                    break;

                //Unknown user type, throw exception
                default:
                    throw new Exception("User Type not found");
            }

            return _currentUser;
        }


        [Required(AllowEmptyStrings = false, ErrorMessage = "*", ErrorMessageResourceName = "")]
        [Display(Name = "User Name")]
        public string UserName
        {
            get; set;
        }

        [Required(AllowEmptyStrings = false, ErrorMessage = "*", ErrorMessageResourceName = "")]
        [Display(Name = "Password")]
        public string Password
        {
            get; set;
        }
    }
}