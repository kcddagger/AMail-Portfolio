﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using AMailBuisnessCore.User;
using AMailBuisnessCore.MessageFolder;
using System.Data;
using AMail.Dbase;
using AMailBuisnessCore.Message;

namespace AMail.Models
{
    public class MessageManager : dbManager
    {
        private List<Message> userFolderMessages;
        private List<Message> archivedMessages;
        private Boolean getArchive = false;
        private int intFolderID = -1;
        private int intUserID = -1;


        

        /// <summary>
        /// A folder ID and User ID will always be required
        /// Messages can not just sit in empty space, they must reside in a folder
        /// </summary>
        /// <param name="folderID"></param>
        /// <param name="userID"></param>
        public MessageManager(int folderID, int userID, bool GetArchive = false)
        {
            intFolderID = folderID;
            intUserID = userID;
            getArchive = GetArchive;
            this.FolderID = folderID;
        }

        /// <summary>
        /// Fill the message list
        /// </summary>
        /// <returns></returns>
        private List<Message> GetMessages()
        {
            List<SqlParameter> parameters = new List<SqlParameter>();
            parameters.Add(new SqlParameter("@intUserID", intUserID));
            parameters.Add(new SqlParameter("@intFolderID", intFolderID));
            DataTable dt = GetDataTableProc("MessageByFolderByUser", parameters);
            DataView dv = new DataView(dt);

            userFolderMessages = new List<Message>();

            foreach (DataRowView message in dv)
            {
                userFolderMessages.Add(new Message(Int32.Parse(message["intID"].ToString())
                    , (message["strMessageSubject"] == DBNull.Value ? "" : message["strMessageSubject"].ToString())
                    , message["strMessageBody"].ToString(), Int32.Parse(message["intAuthorID"].ToString())
                    , Int32.Parse(message["intRecipientID"].ToString()), Int32.Parse(message["intStatus"].ToString())
                    , message["strGUID"].ToString(), message["strAuthoruserName"].ToString()
                    , message["strAuthorFullName"].ToString(), message["strRecipientFullName"].ToString()
                    , message["strRecipientUserName"].ToString(), DateTime.Parse(message["dtSent"].ToString())
                    , (message["dtArchived"] == DBNull.Value ? (DateTime?)null : DateTime.Parse(message["dtArchived"].ToString()))));
            }

            return userFolderMessages;
        }

        private List<Message> GetArchivedMessages()
        {
            if (getArchive)
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@intUserID", intUserID));
                DataTable dt = GetDataTableProc("MessageArchive_S", parameters);
                DataView dv = new DataView(dt);

                archivedMessages = new List<Message>();

                foreach (DataRowView message in dv)
                {
                    archivedMessages.Add(new Message(Int32.Parse(message["intID"].ToString())
                        , (message["strMessageSubject"] == DBNull.Value ? "" : message["strMessageSubject"].ToString())
                        , message["strMessageBody"].ToString(), Int32.Parse(message["intAuthorID"].ToString())
                        , Int32.Parse(message["intRecipientID"].ToString()), Int32.Parse(message["intStatus"].ToString())
                        , message["strGUID"].ToString(), message["strAuthoruserName"].ToString()
                        , message["strAuthorFullName"].ToString(), message["strRecipientFullName"].ToString()
                        , message["strRecipientUserName"].ToString(), DateTime.Parse(message["dtSent"].ToString())
                        , (message["dtArchived"] == DBNull.Value ? (DateTime?)null : DateTime.Parse(message["dtArchived"].ToString()))));
                }
                return archivedMessages;
            }

            return new List<Message>();
        }

        public List<Message> FolderMessages
        {
            get { return userFolderMessages ?? GetMessages(); }
        }

        public List<Message> ArchivedMessages
        {
            get { return archivedMessages ?? GetArchivedMessages(); }
        }

        /// <summary>
        /// Bulk move messages from one folder to another
        /// </summary>
        /// <param name="FolderToMoveTo"></param>
        /// <param name="FolderToMoveFrom"></param>
        /// <param name="messageIDs"></param>
        /// <param name="userID"></param>
        public void MoveMessages(int FolderToMoveTo, int FolderToMoveFrom, string messageIDs, int userID)
        {
            List<SqlParameter> parameters = new List<SqlParameter>();
            parameters.Add(new SqlParameter("@intFolderToMoveTo", FolderToMoveTo));
            parameters.Add(new SqlParameter("@intFolderToMoveFrom", FolderToMoveFrom));
            parameters.Add(new SqlParameter("@intUserID", userID));
            parameters.Add(new SqlParameter("@vcMessageIDs", messageIDs));

            try
            {
                base.UpdateDataProc("Messages_Move", parameters);

            }   
            catch (SqlException moveException)
            { }
        }

        public int FolderID
        {
            get;
        }
    }
}