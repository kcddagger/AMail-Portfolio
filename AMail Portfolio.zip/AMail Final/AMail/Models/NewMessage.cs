﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using AMail.Dbase;
using System.Data.SqlClient;
using AMailBuisnessCore.Media;
using System.ComponentModel.DataAnnotations;

namespace AMail.Models
{
    public class NewMessage : dbManager
    {
        private int intUserID;
        private string strRecipient;
        private int intRecipient;
        private string strMessageSubject;
        private string strMessageBody;
        private int intMessageID;
        private int? intMediaID;

        /// <summary>
        /// sets up all the needed variables to send a new message through the server.
        /// </summary>
        /// <returns></returns>
        public NewMessage(int userID, string recipient, string subject, string body, int? mediaID)
        {
            intUserID = userID;
            strRecipient = recipient;
            strMessageSubject = subject;
            strMessageBody = body;
            intMediaID = mediaID;
            intMessageID = StartMessage(intUserID);
            intRecipient = GetRecipient(strRecipient);
            SendMessage(strMessageBody, strMessageSubject, intRecipient, intMessageID, intUserID, intMediaID);
        }

        /// <summary>
        /// Sets up the new message placeholder on the server.
        /// </summary>
        /// <param name="intUserID"></param>
        /// <returns></returns>
        public int StartMessage(int intUserID)
        {
            List<SqlParameter> parameters = new List<SqlParameter>();
            parameters.Add(new SqlParameter("@intUserID", intUserID));
            DataTable dt = GetDataTableProc("Message_Create", parameters);
            DataView dv = new DataView(dt);
            
            foreach(DataRowView messageID in dv)
            {
                intMessageID = Int32.Parse(messageID["intMessageID"].ToString());
            }

            return intMessageID;
        }


        /// <summary>
        /// Breaks apart the recipient name(s) then uses it in a search of the database to get the matching UserID(s) returning said UserID(s).
        /// Right now this code can only work on one name at a time.  Need to sort out how to search and return multiple names/UIDs in an SProc.
        /// It can be done. Just need to look up and remember how to do it.
        /// </summary>
        /// <param name="strRecipient"></param>
        /// <returns></returns>
        private int GetRecipient(string strRecipient)
        {
            string[] names = strRecipient.Split(' ');
            string strFirstName = names[0].Trim();
            string strLastName = names[1].Trim();

            List<SqlParameter> parameters = new List<SqlParameter>();
            parameters.Add(new SqlParameter("@strFirstName", strFirstName));
            parameters.Add(new SqlParameter("@strLastName", strLastName));
            DataTable dt = GetDataTableProc("Recipient_ID", parameters);
            DataView dv = new DataView(dt);

            foreach (DataRowView recipientID in dv)
            {
                intRecipient = Int32.Parse(recipientID["intUserID"].ToString());
            }

            return intRecipient;
        }

        private void SendMessage(string strMessageBody, string strMessageSubject, int intRecipient, int intMessageID, int intUserID, int? intMediaID)
        {
            List<SqlParameter> parameters = new List<SqlParameter>();
            parameters.Add(new SqlParameter("@strMessageBody", strMessageBody));
            parameters.Add(new SqlParameter("@strMessageSubject", strMessageSubject));
            parameters.Add(new SqlParameter("@intRecipient", intRecipient));
            parameters.Add(new SqlParameter("@intMessageID", intMessageID));
            parameters.Add(new SqlParameter("@intUserID", intUserID));
            parameters.Add(new SqlParameter("@intMediaID", intMediaID));
            DataTable dt = GetDataTableProc("Message_Send", parameters);
        }        
    }
}