﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using AMail.Dbase;
using System.Data.SqlClient;
using System.Data;

namespace AMail.Models
{
    public class PWManage : dbManager
    {
        private int intUserID;
        private string strPassword;

        /// <summary>
        /// Sets up the needed variables to change a user password on the server.
        /// </summary>
        /// <param name="UserID"></param>
        /// <param name="Password"></param>
        /// <param name="ConfPassword"></param>
        public PWManage(int UserID, string Password, string ConfPassword)
        {
            intUserID = UserID;
            strPassword = ComparePassword(Password, ConfPassword);
            ChangePassword(intUserID, strPassword);
        }

        /// <summary>
        /// Double checks to make sure that the password and confirmation match
        /// </summary>
        /// <param name="Password"></param>
        /// <param name="ConfPassword"></param>
        /// <returns></returns>
        private string ComparePassword(string Password, string ConfPassword)
        {
            if (Password == ConfPassword)
            {
                return Password;
            }
            else
            {
                throw new ArgumentException("Passwords must match.");                
            }
        }

        /// <summary>
        /// Calls the database SProc to update the user's password
        /// </summary>
        /// <param name="intUserID"></param>
        /// <param name="strPassword"></param>
        private void ChangePassword(int intUserID, string strPassword)
        {
            List<SqlParameter> parameters = new List<SqlParameter>();
            parameters.Add(new SqlParameter("@intUserID", intUserID));
            parameters.Add(new SqlParameter("@strPassword", strPassword));
            DataTable dt = GetDataTableProc("User_U", parameters);
        }
    }
}