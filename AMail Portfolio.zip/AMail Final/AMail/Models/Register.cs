﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using AMail.Dbase;
using System.Data.SqlClient;
using System.Threading.Tasks;

namespace AMail.Models
{
    public class Register : dbManager
    {
        private Boolean OkToSave = false;
        public Register() { }

        public Register(string FirstName, string LastName, string UserName, string Password, DateTime? DateOfBirth, string EmailAddress)
        {
            this.FirstName = FirstName;
            this.LastName = LastName;
            this.UserName = UserName;
            this.Password = Password;
            this.DateOfBirth = DateOfBirth;
            this.EmailAddress = EmailAddress;
            OkToSave = true;
        }

        /// <summary>
        /// Save the user information to the DB
        /// </summary>
        /// <returns></returns>
        public async Task<Boolean> SaveAsync()
        {
            if (OkToSave)
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@strFirstName", this.FirstName));
                parameters.Add(new SqlParameter("@strLastName", this.LastName));
                parameters.Add(new SqlParameter("@strUserName", this.UserName));
                parameters.Add(new SqlParameter("@strPassword", this.Password));
                parameters.Add(new SqlParameter("@dtDateOfBirth", this.DateOfBirth));
                parameters.Add(new SqlParameter("@strEmailAddress", this.EmailAddress));

                return await InsertDataProcAsync("RegisterUser", parameters);
            }

            throw new Exception("Parameters for register user must be set correctly, make sure you create the register object first prior to calling Save");
        }

        /// <summary>
        /// Save the user information to the DB
        /// </summary>
        /// <returns></returns>
        public Boolean Save()
        {
            if (OkToSave)
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@strFirstName", this.FirstName));
                parameters.Add(new SqlParameter("@strLastName", this.LastName));
                parameters.Add(new SqlParameter("@strUserName", this.UserName));
                parameters.Add(new SqlParameter("@strPassword", this.Password));
                parameters.Add(new SqlParameter("@dtDateOfBirth", this.DateOfBirth));
                parameters.Add(new SqlParameter("@strEmailAddress", this.EmailAddress));

                bool savedOk = InsertDataProc("RegisterUser", parameters);
                this.GUID = ReturnValue.ToString();
                return savedOk;
            }

            throw new Exception("Parameters for register user must be set correctly, make sure you create the register object first prior to calling Save");
        }

        [Required(AllowEmptyStrings = false, ErrorMessage ="*", ErrorMessageResourceName ="")]
        [Display(Name ="First Name")]
        public string FirstName
        { get; set; }

        [Required(AllowEmptyStrings = false, ErrorMessage = "*", ErrorMessageResourceName = "")]
        [Display(Name = "Last Name")]
        public string LastName
        { get;  set; }

        [Required(AllowEmptyStrings = false, ErrorMessage = "*", ErrorMessageResourceName = "")]
        [Display(Name = "Date Of Birth")]
        public DateTime? DateOfBirth
        { get;  set; }

        [Required(AllowEmptyStrings = false, ErrorMessage = "*", ErrorMessageResourceName = "")]
        [Display(Name = "User Name")]
        public string UserName
        { get;  set; }

        [Required(AllowEmptyStrings = false, ErrorMessage = "*", ErrorMessageResourceName = "")]
        [Display(Name = "Password")]
        public string Password
        { get;  set; }

        [Required(AllowEmptyStrings = false, ErrorMessage = "*", ErrorMessageResourceName = "")]
        [Display(Name = " Confirm Password")]
        [Compare("Password")]
        public string ConfPassword
        { get;  set; }

        public string EmailAddress
        { get; protected set; }

        public string GUID
        {
            get;protected set;
        }
    }
}