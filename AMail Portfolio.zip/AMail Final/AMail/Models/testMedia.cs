﻿using System;
using System.Collections.Generic;
using System.Drawing.Imaging;
using System.Drawing;


namespace AMail.Models
{
    public class testMedia
    {
        //Stream we will use for thumbnail
        private System.IO.MemoryStream _thumbNailStream = new System.IO.MemoryStream();

        public testMedia(byte[] _image)
        {
            //Create a memory stream from the existing image
            System.IO.MemoryStream ms = new System.IO.MemoryStream(_image);
            
            //Create an image from the stream
            Image i = Image.FromStream(ms);
            //Object for the thumb nail
            Image thumbnail = null;

            //Create refence for the original height and width
            float height = i.Height;
            float width = i.Width;
            
            //Height and width for the thumbnail
            float thumbHeight = height;
            float thumbWidth = width;
            
            //By default the thumbnail can't be any bigger than 80x80 pixel(this can be changed)
            if(height>80 || width>80)
            {
                //What is our aspect ratio
                float _ratio = width / height;
               
                if (_ratio>=1)
                {
                    //Height is greater or the two, scale height by ratio
                    thumbWidth = 80;
                    thumbHeight = 80f / _ratio;
                }
                else
                {
                    //Width is greater of the two, scale width by ratio
                    thumbHeight = 80;
                    thumbWidth = 80f / _ratio;
                }

                //generate thumbnail, pass in the new width and height, 
                //The null parameter is for a call back, so if we wanted to be notified when and if the process should be aborted we would 
                //put a delegate there.
                thumbnail = i.GetThumbnailImage((int)thumbWidth, (int)thumbHeight, null, System.IntPtr.Zero);
                //Save the image to a memory stream and not to disk
                thumbnail.Save(_thumbNailStream, ImageFormat.Jpeg);
                //Set the public property so we can access this stream from outside the claass
                ThumbNailStream = _thumbNailStream;
                //Create a byte array from the stream just in case
                ThumbNailByteArray = _thumbNailStream.ToArray();

                //Clean up
                _thumbNailStream.Close();
                ms.Close();
                i.Dispose();
                thumbnail.Dispose();
                _thumbNailStream.Dispose();
                ms.Dispose();
            }
        }

        /// <summary>
        /// The byte array of the thumbnail
        /// </summary>
        public byte[] ThumbNailByteArray
        {
            get;
        }

        /// <summary>
        /// The stream for the new thumbnail
        /// </summary>
        public System.IO.MemoryStream ThumbNailStream
        {
            get;
        }
    }
}