﻿var TeamDetailPostBackURL = '/FolderManager/DeleteFolderModal';  
$(function () {
    $(".deleteFolder").click(function () {
        //debugger;
        var $buttonClicked = $(this);
        var id = $buttonClicked.attr('data-id');
        var options = { "backdrop": "static", keyboard: true };
        $.ajax({
            type: "GET",
            url: TeamDetailPostBackURL,
            contentType: "application/json; charset=utf-8",
            data: { "Id": id },
            datatype: "json",
            success: function (data) {
                //debugger;
                $('#RemoveFolderModalContent').html(data);
                $('#RemoveFolderModal').modal(options);
                $('#RemoveFolderModal').modal('show');

            },
            error: function () {
                alert("Dynamic content load failed.");
            }
        });
    });
    $("#closbtn").click(function () {
        $('#RemoveFolderModal').modal('hide');
    });


});  


var postBackURL = '/FolderManager/CheckboxIDS';
$(function () {
    $(".messageMove").click(function () {
        //debugger;
        //Find all the checkboxes for messages
        var checkBoxes = document.getElementsByName("mCheckBox");
        var ids = "";
        //Loop through checkboxs and find which ones are checked.
        for (var i = 0; i < checkBoxes.length; i++) {
            if (checkBoxes[i].checked) {
                ids += checkBoxes[i].id + ',';
            }
        }
        var dataObject = JSON.stringify({
            'messageIDs': ids
        });

        var options = { "backdrop": "static", keyboard: true };
        $.ajax({
            type: "POST",
            url: postBackURL,
            contentType: "application/json; charset=utf-8",
            data: dataObject,
            datatype: "json",
            success: function (data) {
                //debugger;
                $('#MoveMessageModalContent').html(data);
                $('#MoveMessageModal').modal(options);
                $('#MoveMessageModal').modal('show');

            },
            error: function () {
                alert("Dynamic content load failed.");
            }
        });
    });
    $("#closbtn").click(function () {
        $('#MoveMessageModal').modal('hide');
    });

    $('#ArchiveMessageModal').on('show.bs.modal', function (event)
    {
        var button = $(event.relatedTarget); // Button that triggered the modal
        //alert('button = ' + button);
        var messageID = button.data('id'); // Extract info from data-* attributes
        //alert('Message ID =' + messageID);
        // If necessary, you could initiate an AJAX request here (and then do the updating in a callback).
        // Update the modal's content. We'll use jQuery here, but you could use a data binding library or other methods instead.
        var modal = $(this);
        modal.find('.modal-body input#messageID').val(messageID);
    });

    $("a[data-form-method='post']").click(function (event)
    {
        event.preventDefault();
        var element = $(this);
        var action = element.attr("href");
        element.closest("form").each(function ()
        {
            var form = $(this);
            form.attr("action", action);
            form.submit();
        });
    });
});

///Autocomplete for when creating a new message
$(document).ready(function () {
    $("#recipient").autocomplete({
        source: function (request, response) {
            $.ajax({
                url: "/AutoComplete/GetUsers",
                type: "POST",
                dataType: "json",
                data: { Prefix: request.term },
                success: function (data) {
                    response($.map(data, function (item) {
                        return { label: item, value: item };
                    }));
                }
            })
        }
    });
})