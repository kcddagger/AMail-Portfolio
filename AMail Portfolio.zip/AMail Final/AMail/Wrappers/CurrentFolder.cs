﻿using System;
using System.Collections.Generic;
using System.Web;
using AMailBuisnessCore.MessageFolder;
using AMailBuisnessCore.Message;

namespace AMail.Wrappers
{
    public static class CurrentFolder
    {
        private static string _currentFolder = "currentFolder";
        private static string _currentFolderList = "currentFolderList";
        private static string _currentMessageList = "currentMessageList";

        /// <summary>
        /// Return a List of all the current users folders
        /// </summary>
        /// <param name="_context"></param>
        /// <returns></returns>
        public static List<Folder> GetCurrentFolderList(HttpSessionStateBase _context)
        {
            return ((List<Folder>)_context[_currentFolderList]);
        }

        /// <summary>
        /// Set the current users folder list
        /// </summary>
        /// <param name="_context"></param>
        /// <param name="folderList"></param>
        public static void SetCurrentFolderList(HttpSessionStateBase _context, List<Folder> folderList)
        {
            _context[_currentFolderList] = folderList;
        }

        /// <summary>
        /// Return the current folder the user is currently in
        /// </summary>
        /// <param name="_context"></param>
        /// <returns></returns>
        public static Folder GetWorkingFolder(HttpSessionStateBase _context)
        {
            return ((Folder)_context[_currentFolder]);
        }

        /// <summary>
        /// Set the folder the user is currently in
        /// </summary>
        /// <param name="_context"></param>
        /// <param name="f"></param>
        public static void SetWorkingFolder(HttpSessionStateBase _context, Folder f)
        {
            _context[_currentFolder] = f;
        }

        /// <summary>
        /// Purge user Folder settings on logout
        /// </summary>
        /// <param name="_context"></param>
        public static void Logout(HttpSessionStateBase _context)
        {
            _context[_currentFolder] = null;
            _context[_currentFolderList] = null;
            _context.Remove(_currentFolder);
            _context.Remove(_currentFolderList);
        }


        public static Message GetMessageByID(int messageID, HttpSessionStateBase _context)
        {
            return ((Message)((List<Message>)_context[_currentFolderList]).Find(t => t.ID == messageID));
        }


        public static void SetCurrentMessageList(HttpSessionStateBase _context, List<Message> messageList)
        {
            _context[_currentMessageList] = messageList;
        }


        public static List<Message> GetCurrentMessageList(HttpSessionStateBase _context)
        {

            return ((List<Message>)_context[_currentMessageList]);
        }
    }
}