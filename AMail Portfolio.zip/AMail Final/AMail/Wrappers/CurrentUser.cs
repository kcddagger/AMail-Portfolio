﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using AMailBuisnessCore.User;

namespace AMail.Wrappers
{
    public class CurrentUser 
    {
        private static string _currentUser = "currentUser";
        private static string _userGUID = "userGUID";

        /// <summary>
        /// Get the password for the current user
        /// </summary>
        /// <param name="_context"></param>
        /// <returns></returns>
        public static string Password(HttpSessionStateBase _context)
        {
            if (CurrentUserNotNull(_context))
                return ((IUser)_context[_currentUser]).PassWord;

            return "";
        }

        /// <summary>
        /// Get the user name for the current user
        /// </summary>
        /// <param name="_context"></param>
        /// <returns></returns>
        public static string UserName(HttpSessionStateBase _context)
        {
            if (CurrentUserNotNull(_context))
                return ((IUser)_context[_currentUser]).UserName;

            return "";
        }

        /// <summary>
        /// See if the current user is valid
        /// </summary>
        /// <param name="_context"></param>
        /// <returns></returns>
        public static Boolean IsValid(HttpSessionStateBase _context)
        {
            if (CurrentUserNotNull(_context))
                return true;

            return false;
        }

        /// <summary>
        /// Log out the current user
        /// </summary>
        /// <param name="_context"></param>
        public static void Logout(HttpSessionStateBase _context)
        {
            _context[_currentUser] = null;
            _context[_userGUID] = null;
            _context.Remove(_userGUID);
            _context.Remove(_currentUser);
        }

        /// <summary>
        /// Set the current user in session
        /// </summary>
        /// <param name="_context"></param>
        /// <param name="value"></param>
        public static void SetUser(HttpSessionStateBase _context, object value)
        {
            _context[_currentUser] = value;
        }



        /// <summary>
        /// Check to see if GUID is set for the current user
        /// </summary>
        /// <param name="_context"></param>
        /// <returns></returns>
        public static Boolean HasGUID(HttpSessionStateBase _context)
        {
            if (_context[_userGUID] != null)
                return true;

            return false;
        }

        /// <summary>
        /// Get the GUID for the current user
        /// </summary>
        /// <param name="_context"></param>
        /// <returns></returns>
        public static string GetGUID(HttpSessionStateBase _context)
        {
            if (_context[_userGUID] != null)
                return _context[_userGUID].ToString();

            return string.Empty;
        }

        /// <summary>
        /// Takes the Session and derives the user variables, returning the Person's details for use.
        /// </summary>
        /// <param name="_context"></param>
        /// <returns>a Person Object</returns>
        public static Person GetPerson(HttpSessionStateBase _context)
        {
            if(_context[_currentUser] != null)
                return ((Person)_context[_currentUser]);

            return null;
        }

        /// <summary>
        /// Set the GUID for the current user
        /// </summary>
        /// <param name="_context"></param>
        /// <param name="value"></param>
        public static void SetGUID(HttpSessionStateBase _context, string value)
        {
            _context[_userGUID] = value;
        }

        /// <summary>
        /// Checks that the user is logged in with a valid account and session settings.
        /// </summary>
        /// <param name="_context"></param>
        /// <returns></returns>
        private static Boolean CurrentUserNotNull(HttpSessionStateBase _context)
        {
            if (_context[_currentUser] != null)
                return true;

            return false;
        }        
    }
}