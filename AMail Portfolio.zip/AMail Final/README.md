# AMail
Practice application
