USE [amail]
GO

/****** Object:  StoredProcedure [dbo].[AuthenticateLogin]    Script Date: 8/20/2018 12:11:52 PM ******/
DROP PROCEDURE [dbo].[AuthenticateLogin]
GO

/****** Object:  StoredProcedure [dbo].[AuthenticateLogin]    Script Date: 8/20/2018 12:11:52 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Brad Mandery>
-- Create date: <7-16-2018>
-- Description:	<Simple proc to authenticate a user>
-- =============================================
CREATE PROCEDURE [dbo].[AuthenticateLogin]
@strUserName varchar(300) = null
, @strPassword varchar(255) = null
AS
BEGIN
	SET NOCOUNT ON;

		if(@strUserName IS NOT NULL and @strPassword IS NOT NULL)
			BEGIN

				Select *, u.intID as [intUserID], (select intFOlderID FROM tblFolderByUser where intUserID=u.intID and intType=1)as[DefaultFolderID], u.dtUpdated AS [dtLastLogin] FROM tblPerson p left join tblUser u on p.intID=u.intPersonID where u.strPassword=@strPassword and u.strUserName=@strUserName

				Update tblUser set intLoginCount=intLoginCount+1 where intID=(Select intID FROM tblUser where strPassword=@strPassword and strUserName=@strUserName)
				
			END
END



--exec AuthenticateLogin 'bmandery', 'fast'
GO

