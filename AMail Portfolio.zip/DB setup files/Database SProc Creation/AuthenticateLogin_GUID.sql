USE [amail]
GO

/****** Object:  StoredProcedure [dbo].[AuthenticateLogin_GUID]    Script Date: 8/20/2018 12:12:12 PM ******/
DROP PROCEDURE [dbo].[AuthenticateLogin_GUID]
GO

/****** Object:  StoredProcedure [dbo].[AuthenticateLogin_GUID]    Script Date: 8/20/2018 12:12:12 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Brad Mandery>
-- Create date: <7-18-2018>
-- Description:	<Another way for us to authenticate a user, with their GUID that is assigned to the
--This won't be something the user will know, it's just used for a mechanisim to log the user in via the system>
-- =============================================
CREATE PROCEDURE [dbo].[AuthenticateLogin_GUID]
@guid varchar(max) = null
AS
BEGIN
	SET NOCOUNT ON;

	if(@guid IS NOT NULL)
		BEGIN
			Select *, u.intID as [intUserID], (select intFOlderID FROM tblFolderByUser where intUserID=u.intID and intType=1)as[DefaultFolderID], u.dtUpdated as [dtLastLogin] FROM tblPerson p left join tblUser u on p.intID=u.intPersonID where p.strGUID=@guid

			Update tblUser set intLoginCount=intLoginCount+1 where intID=(Select intID FROM tblUser where intPersonID=(Select intID FROM tblPerson where strGUID=@guid))
		END
END


--exec AUthenticateLogin_GUID '7DBCABE6-CE4B-40F7-B004-08F508C3B816'
GO

