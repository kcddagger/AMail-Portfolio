USE [amail]
GO

/****** Object:  StoredProcedure [dbo].[FolderByUserID]    Script Date: 8/20/2018 12:13:01 PM ******/
DROP PROCEDURE [dbo].[FolderByUserID]
GO

/****** Object:  StoredProcedure [dbo].[FolderByUserID]    Script Date: 8/20/2018 12:13:01 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Brad Mandery>
-- Create date: <7-20-2018>
-- Description:	<Get all the folders a user has assocciated with them>
-- =============================================
CREATE PROCEDURE [dbo].[FolderByUserID]
@intUserID INT = null
AS
BEGIN
	SET NOCOUNT ON;

		if(@intUserID IS NOT NULL)
			BEGIN
				Select *
					, (Select count(*) 
						from tblMessageByFolder mbf 
							left join tblMessageByUser mbu 
							on mbf.intMessageID=mbu.intMessageID 
						where intFolderID=fbu.intFolderID and intUserID=@intUserID
						--Make sure we are not counting archived messages
						/*Edited: 8-16-2018 by: B.Mandery*/
						and ((4 & mbu.intStatus) != 4)) as [MessageCount] 
				FROM tblFolderByUser fbu left join tblFolder f on fbu.intFolderID=f.intID where intUserID=@intUserID
			END
END




GO

