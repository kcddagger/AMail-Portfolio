USE [amail]
GO

/****** Object:  StoredProcedure [dbo].[FolderByUser_Delete]    Script Date: 8/20/2018 12:12:46 PM ******/
DROP PROCEDURE [dbo].[FolderByUser_Delete]
GO

/****** Object:  StoredProcedure [dbo].[FolderByUser_Delete]    Script Date: 8/20/2018 12:12:46 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Brad Mandery>
-- Create date: <8-3-2018>
-- Description:	<Remove a folder associated to a user>
-- =============================================
CREATE PROCEDURE [dbo].[FolderByUser_Delete] 
@intFolderID INT = null,
@intUserID INT = null
AS
BEGIN
	SET NOCOUNT ON;

	--Make sure we have valid values and that the folder isn't a permanent folder
		if(@intFolderID IS NOT NULL and @intUserID IS NOT NULL and (Select bitPermanent from tblFolder where intID=@intFolderID)=0)
			BEGIN
				--Make sure this USER ID owns this folder
				if exists(select * from tblFolderByUser where intFolderID=@intFolderID and intUserID=@intUserID)
					BEGIN
						BEGIN TRY
							delete from tblFolderByUser where intUserID=@intUserID and intFolderID=@intFolderID--Remove the Folder from the user table
							delete from tblFolder where intID=@intFolderID -- remove the folder from the folder table
							Select Convert(bit,1)--return true is success
							return
						END TRY
						BEGIN CATCH--Some type of error occured return false
							Select Convert(bit,0)
							return
						END CATCH
					END
			END
			Select Convert(bit,0)--return false
END
GO

