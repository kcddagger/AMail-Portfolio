USE [amail]
GO

/****** Object:  StoredProcedure [dbo].[Folder_IU]    Script Date: 8/20/2018 12:12:27 PM ******/
DROP PROCEDURE [dbo].[Folder_IU]
GO

/****** Object:  StoredProcedure [dbo].[Folder_IU]    Script Date: 8/20/2018 12:12:27 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Brad Mandery>
--- Create date: <7-24-2018
--- Description:	<Create a new folder for a given user/Update a folder>
-- =============================================
CREATE PROCEDURE [dbo].[Folder_IU] 
@strFolderName Varchar(255) = null
, @intOwnerID INT = null
, @intParentFolderID INT = null
, @intFolderID INT = null
AS
BEGIN
	SET NOCOUNT ON;

		if(@intFolderID IS NULL)
			BEGIN
				--Creating a new folder
				--Create a unique guid
				declare @GUID uniqueidentifier 
					set @GUID = newid()

				--Insert the folder
				INSERT INTO tblFolder (strName, bitPermanent, intParentID, strGUID) Values(@strFolderName,0,@intParentFolderID, @GUID)

				--Get the new folder ID
				set @intFolderID = (select intID from tblFolder where strGUID=@GUID)

				--Assocciate the folder to the user now
				INSERT INTO tblFolderByUser(intFolderID, intUserID, intType) values(@intFolderID, @intOwnerID,4)

			END
		else
			BEGIN
				--Updating a folder
				Update tblFolder set intParentID=@intParentFolderID, strName=@strFolderName where intID=@intFolderID
			END
END
GO

