USE [amail]
GO

/****** Object:  StoredProcedure [dbo].[GetAttachment]    Script Date: 8/20/2018 12:13:14 PM ******/
DROP PROCEDURE [dbo].[GetAttachment]
GO

/****** Object:  StoredProcedure [dbo].[GetAttachment]    Script Date: 8/20/2018 12:13:14 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Crystal Buckneberg>
-- Create date: <08-14-2018>
-- Description:	<Pulls data from tblMedia selected by the input message and media IDs.>
-- =============================================
CREATE PROCEDURE [dbo].[GetAttachment] 
	@intMessageID int = NULL, 
	@intMediaID int = NULL
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- ensures that the media pulled belongs to the message, and thus the user that is calling for it.
	SELECT m.intID AS [ID], m.strName AS [Name], m.binMedia AS [Content], m.guid AS [GUID], m.strContentType AS [ContentType], m.strExtension AS [Extension], m.dtCreated AS [Created]
	FROM tblMedia m LEFT JOIN tblMessageByMedia mbm ON m.intID = mbm.intMediaID
	WHERE m.intID = 
		(SELECT mbm.intMediaID 
		 FROM tblMessageByMedia
		 WHERE mbm.intMessageID = @intMessageID AND mbm.intMediaID = @intMediaID)
END
GO

