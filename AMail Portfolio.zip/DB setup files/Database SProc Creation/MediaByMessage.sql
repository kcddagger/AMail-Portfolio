USE [amail]
GO

/****** Object:  StoredProcedure [dbo].[MediaByMessage]    Script Date: 8/20/2018 12:13:31 PM ******/
DROP PROCEDURE [dbo].[MediaByMessage]
GO

/****** Object:  StoredProcedure [dbo].[MediaByMessage]    Script Date: 8/20/2018 12:13:31 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Brad Mandery>
-- Create date: <8-14-2018>
-- Description:	<Get all media for a message>
-- =============================================
CREATE PROCEDURE [dbo].[MediaByMessage]
	@intMessageID INT = null
AS
BEGIN
	SET NOCOUNT ON;

		if(@intMessageID IS NOT NULL)
			BEGIN
				select * FROM tblMessageByMedia left join tblMedia m on intMediaID=m.intID where intMessageID=@intMessageID
			END
END
GO

