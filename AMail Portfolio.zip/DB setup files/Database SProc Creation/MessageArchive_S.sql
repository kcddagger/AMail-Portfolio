USE [amail]
GO

/****** Object:  StoredProcedure [dbo].[MessageArchive_S]    Script Date: 8/20/2018 12:15:44 PM ******/
DROP PROCEDURE [dbo].[MessageArchive_S]
GO

/****** Object:  StoredProcedure [dbo].[MessageArchive_S]    Script Date: 8/20/2018 12:15:44 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Brad Mandery>
-- Create date: <8-16-2018>
-- Description:	<Get all messages that have the archive bit turned on>
-- =============================================
CREATE PROCEDURE [dbo].[MessageArchive_S]
@intUserID INT = null
AS
BEGIN
	SET NOCOUNT ON;

		--First make sure the user is an admin
			if( (Select intUserTypeID FROm tblUser where intID=@intUserID) = 2)
				BEGIN--Get all message that have an archive status
					Select *
						, (Select strUserName from tblUser where intID=(Select intUserID from tblMessageByUser where intMessageID=m.intID and intUserID!=r.intUserID)) as [strAuthorUserName]
						, (select strUserName from tblUser where intID=r.intUserID) as [strRecipientUserName]
						,r.intUserID as [intRecipientID]
						, m.dtCreated as [dtSent]
						, (Select intUserID from tblMessageByUser where intMessageID=m.intID and intUserID!=r.intUserID) as [intAuthorID]
						,(Select strFirstName + ' ' + strLastName from tblPerson where intID =(Select intPersonID FROM tbluser where intID=r.intUserID)) as [strRecipientFullName]
						,(Select strFirstName + ' ' + strLastName from tblPerson where intID =(Select intPersonID FROM tblUser where intID=(Select intUserID from tblMessageByUser where intMessageID=m.intID and intUserID!=r.intUserID))) as [strAuthorFullName]
					 FROM tblMessage m right join tblMessageByUser r on m.intID=r.intMessageID where m.intID in 
						(Select intMessageID from tblMessageByUser where (4&intStatus)=4)
						and (4&r.intStatus)=4 and r.dtArchived IS NOT NULL
						
				END
END





GO

