USE [amail]
GO

/****** Object:  StoredProcedure [dbo].[MessageByFolderByUser]    Script Date: 8/20/2018 12:16:04 PM ******/
DROP PROCEDURE [dbo].[MessageByFolderByUser]
GO

/****** Object:  StoredProcedure [dbo].[MessageByFolderByUser]    Script Date: 8/20/2018 12:16:04 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Brad Mandery>
-- Create date: <7-24-2018>
-- Description:	<Get message by user and folder ID>
-- =============================================
-- **********************************************
-- Change Log: 8-2-2018
-- By: Brad Mandery
-- Adding a small security check to make sure the incoming folder ID and user id are a pair
-- This is to ensure that you can't view another users folder messages by simply typing in a folder id in the query string.
-- **********************************************
-- Change Log: 8-16-2018
-- By: Brad Mandery
-- Change Made: Add further check to WHERE clause to prevent the listing of Archived messages
-- **********************************************

CREATE PROCEDURE [dbo].[MessageByFolderByUser] 
@intUserID INT = null
, @intFolderID INT = null
AS
BEGIN
	SET NOCOUNT ON;

	
	if exists(Select intFolderID from tblFolderByUser where intUserID=@intUserID and intFolderID=@intFolderID)
		BEGIN
			if(@intUserID is not null and @intFolderID is not null)
				BEGIN
								--Get messageids in inbox										--Get the inbox for a user
					Select *
					, (Select intUserID from tblMessageByUser where intMessageID=m.intID and (intStatus&1)=1) as [intAuthorID] 
					, (Select strFirstName + ' ' + strLastName FROM tblPerson where intID IN(Select intPersonID FROM tblUser where intID in(Select intUserID FROM tblMessageByUser where intUserID != @intUserID and intMessageID=m.intID))) as [strRecipientFullName]
					, (Select strFirstName + ' ' + strLastName FROM tblPerson where intID IN(Select intPersonID FROM tblUser where intID=(Select intUserID from tblMessageByUser where intMessageID=m.intID and (intStatus&1)=1))) as [strAuthorFullName]
					, (Select strUserName FROM tblUser where intID=(Select intUserID FROM tblMessageByUser where intUserID != @intUserID and intMessageID=m.intID)) as [strRecipientUserName]
					, (Select strUserName FROM tblUser where intID=(Select intUserID from tblMessageByUser where intMessageID=m.intID and (intStatus&1)=1)) as [strAuthorUserName]
					, m.dtCreated as [dtSent]
					, (Select intUserID FROM tblMessageByUser where intUserID != @intUserID and intMessageID=m.intID) as [intRecipientID]
					FROM tblMessage m left join tblMessageByUser mbu on m.intid=mbu.intMessageID 
					where intID IN(Select intMessageID FROM tblMessageByFolder where intFolderID=@intFolderID) and mbu.intUserID=@intUserID
					and (Select intUserID FROM tblMessageByUser where intUserID != @intUserID and intMessageID=m.intID) IS NOT NULL
					and (4 & mbu.intStatus) != 4 -- Make sure we aren't getting messages that are archived
					order by m.dtCreated desc
				END
		END
END

--exec MessageByFolderByUser 44,12
GO

