USE [amail]
GO

/****** Object:  StoredProcedure [dbo].[MessageByIDByUser]    Script Date: 8/20/2018 12:16:25 PM ******/
DROP PROCEDURE [dbo].[MessageByIDByUser]
GO

/****** Object:  StoredProcedure [dbo].[MessageByIDByUser]    Script Date: 8/20/2018 12:16:25 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Crystal Buckneberg>
-- Create date: <7-30-2018>
-- Description:	<Get single message by user and message ID>
-- =============================================
--********************************************************
-- Change Log: 8-2-2018
-- By: Brad Mandery
-- Change Made: Adding in a security check to make sure the incoming user id has access to the messageid
-- 
--By: Crystal Buckneberg
--Change Made: Changed 2nd IS NULL select to intID from intMediaID to get proper media Name
--

CREATE PROCEDURE [dbo].[MessageByIDByUser] 
	@intUserID INT = null,
	@intMessageID INT = null
AS
BEGIN
	SET NOCOUNT ON;

	if exists(Select intMessageID FROM tblMessageByUser where intMessageID=@intMessageID and intUserID=@intUserID)
		BEGIN
			if(@intUserID is not null and @intMessageID is not null)
				BEGIN
					
					--Update message so its marked as read
					if( (Select (2&intStatus) from tblMessageByUser where intMessageID=@intMessageID and intUserID=@intUserID) = 2)
						BEGIN
							update tblMessageByUser set intStatus=intStatus-2 where intMessageID=@intMessageID and intUserID=@intUserID
							--update tblMessageByUser set intStatus=intStatus+64 where intMessageID=@intMessageID and intUserID=@intUserID
						END
								--Get Message data for the user										
					Select *
					, (Select intUserID from tblMessageByUser where intMessageID=m.intID and (intStatus&1)=1) as [intAuthorID] 
					, (Select strFirstName + ' ' + strLastName FROM tblPerson where intID IN(Select intPersonID FROM tblUser where intID=mbu.intUserID)) as [strRecipientFullName]
					, (Select strFirstName + ' ' + strLastName FROM tblPerson where intID IN(Select intPersonID FROM tblUser where intID=(Select intUserID from tblMessageByUser where intMessageID=m.intID and (intStatus&1)=1))) as [strAuthorFullName]
					, (Select strUserName FROM tblUser where intID=@intUserID) as [strRecipientUserName]
					, (Select strUserName FROM tblUser where intID=(Select intUserID from tblMessageByUser where intMessageID=m.intID and (intStatus&1)=1)) as [strAuthorUserName]
					, isnull(messBM.intMediaID,null) as [MediaID]
					, isnull((Select top 1 strName FROM tblMedia where intID=messBM.intMediaID),null) as [MediaName]
					, intUserID as [intRecipientID]
					, m.dtCreated as [dtSent]
					FROM tblMessage m left join tblMessageByUser mbu on m.intID=mbu.intMessageID 
					left join tblMessageByMedia messBM on mbu.intMessageID=messBm.intMessageID
					where intID IN(Select intMessageID FROM tblMessageByUser where intMessageID=@intMessageID) and mbu.intUserID=@intUserID


					
				END
		END
END


--exec [MessageByIDByUser] 48,27



GO

