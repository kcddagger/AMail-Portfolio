USE [amail]
GO

/****** Object:  StoredProcedure [dbo].[Message_Copy]    Script Date: 8/20/2018 12:14:04 PM ******/
DROP PROCEDURE [dbo].[Message_Copy]
GO

/****** Object:  StoredProcedure [dbo].[Message_Copy]    Script Date: 8/20/2018 12:14:04 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Brad Mandery>
-- Create date: <8-17-2018>
-- Description:	<Proc to copy the supplied message ID and return the newly created message ID>
-- =============================================
CREATE PROCEDURE [dbo].[Message_Copy]
@intMessageID int null
,@intNextMessageID INT OUTPUT
AS
BEGIN
	SET NOCOUNT ON;

		Declare @strGuid uniqueidentifier
		Declare @strSubject varchar(max)
		Declare @strBody varchar(max)

		set @strGuid = NEWID()
		set @strSubject = (Select strMessageSubject FROM tblMessage where intID=@intMessageID)
		set @strBody = (Select strMessageBody FROM tblMessage where intID=@intMessageID)




		INSERT INTO tblMessage(strMessageBody, strMessageSubject, strGUID)
			Values(@strBody, @strSubject, @strGuid)


			--Select the newly created message ID
			set @intNextMessageID = (select intID FROM tblMessage where strGUID=@strGuid)
			

END
GO

