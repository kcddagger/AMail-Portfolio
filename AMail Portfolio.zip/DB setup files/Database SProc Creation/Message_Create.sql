USE [amail]
GO

/****** Object:  StoredProcedure [dbo].[Message_Create]    Script Date: 8/20/2018 12:14:24 PM ******/
DROP PROCEDURE [dbo].[Message_Create]
GO

/****** Object:  StoredProcedure [dbo].[Message_Create]    Script Date: 8/20/2018 12:14:24 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Brad Mandery>
-- Create date: <7-24-2018>
-- Description:	<Create new BLANK message for a user>
-- =============================================
CREATE PROCEDURE [dbo].[Message_Create]
@intUserID INT = null
AS
BEGIN

	SET NOCOUNT ON;

		if(@intUserID IS NOT NULL)
			BEGIN
				declare @guid uniqueidentifier
					set @guid = newid()

				INSERT INTO tblMessage(strMessageBody, strMessageSubject, strGUID)
					Values('','',@guid)

				declare @intMessageID int
					set @intMessageID = (select intID from tblMessage where strGUID=@guid)



				insert into tblMessageByUser(intMessageID, intUserID,intStatus) values(@intMessageID, @intUserID, 0)


				select @intMessageID as intMessageID
			END
END
GO

