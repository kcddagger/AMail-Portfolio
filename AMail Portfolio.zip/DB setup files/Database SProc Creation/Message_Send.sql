USE [amail]
GO

/****** Object:  StoredProcedure [dbo].[Message_Send]    Script Date: 8/20/2018 12:14:44 PM ******/
DROP PROCEDURE [dbo].[Message_Send]
GO

/****** Object:  StoredProcedure [dbo].[Message_Send]    Script Date: 8/20/2018 12:14:44 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Brad Mandery>
-- Edited By:   <Crystal Buckneberg>
-- Create date: <7-24-2018>
-- Description:	<Send/Save a message with/without attachment after it has been created>
-- =============================================
CREATE PROCEDURE [dbo].[Message_Send]
@strMessageBody varchar(max) = NULL
, @strMessageSubject varchar(max) = NULL
, @intRecipient int = NULL
, @intMessageID int = NULL
, @intUserID int = NULL --Author
, @intMediaID int = NULL
, @bitSendToAll bit = null
AS
BEGIN
	SET NOCOUNT ON;


	--Make sure we have a valid messsage id
	IF EXISTS(select intID FROM tblMessage where intID=@intMessageID)
		BEGIN
			--save message 
			UPDATE tblMessage 
				SET strMessageBody=@strMessageBody
				, strMessageSubject=@strMessageSubject
			WHERE intID=@intMessageID

			--Link to sent FOLDER --Author
			INSERT INTO tblMessageByFolder(intMessageID, intFolderID) VALUES(@intMessageID, (SELECT intFolderID FROM tblFolder f LEFT JOIN tblFolderByUser fbu ON f.intID=fbu.intFolderID WHERE fbu.intUserID=@intUserID AND f.strName='sent'))

		--Check to see if we need to send this to all users
		if(@bitSendToAll is null)
			BEGIN

				--Media Check here, instead of duplicating all the updates and inserts
				IF (EXISTS(SELECT intID FROM tblMedia WHERE intID=@intMediaID))
					BEGIN
						--Update MessageByUser -- set status for author to SENT, CONTAINS_ATTACHMENT, and UNREAD
						UPDATE tblMessageByUser SET intStatus=intStatus+19 WHERE intMessageID=@intMessageID AND intUserID=@intUserID

						--Create MessageByUser record for receipient --Set status as NEW, UNREAD, and CONTAINS_ATTACHMENT
						INSERT INTO tblMessageByUser(intMessageID, intUserID, intStatus) VALUES(@intMessageID, @intRecipient, 18)
					
						--Create MessageByMedia record for message
						INSERT INTO tblMessageByMedia(intMessageID, intMediaID) VALUES(@intMessageID, @intMediaID)
					END
				ELSE
					BEGIN
						--Update MessageByUser -- set status for author to SENT and UNREAD
						UPDATE tblMessageByUser SET intStatus=intStatus+3 WHERE intMessageID=@intMessageID AND intUserID=@intUserID
					
						--Create MessageByUser record for receipient --Set status as NEW and UNREAD
						INSERT INTO tblMessageByUser(intMessageID, intUserID, intStatus) VALUES(@intMessageID, @intRecipient, 2)
					END

				--Link to inbox
				INSERT INTO tblMessageByFolder(intMessageID, intFolderID) VALUES(@intMessageID, (SELECT intFolderID FROM tblFolder f LEFT JOIN tblFolderByUser fbu ON f.intID=fbu.intFolderID WHERE fbu.intUserID=@intRecipient AND f.strName='inbox'))
			END
		ELSE
			BEGIN
				declare @UserTable table
				(
					intUserID INT
				)

				INSERT INTO @UserTable	
					Select top 2 intID FROM tblUser where intID!=@intUserID

				Declare @intCurrentUserID INT
				Declare @intNextMessageID INT

				IF (EXISTS(SELECT intID FROM tblMedia WHERE intID=@intMediaID))
					BEGIN
						--Update MessageByUser -- set status for author to SENT, CONTAINS_ATTACHMENT, and UNREAD
						UPDATE tblMessageByUser SET intStatus=intStatus+19 WHERE intMessageID=@intMessageID AND intUserID=@intUserID
					END
				ELSE
					BEGIN
						--Update MessageByUser -- set status for author to SENT and UNREAD
						UPDATE tblMessageByUser SET intStatus=intStatus+3 WHERE intMessageID=@intMessageID AND intUserID=@intUserID
					END


				While( select count(*) from @UserTable)>0
					BEGIN
						--Get next user
						set @intCurrentUserID = (Select TOP 1 intUserID FROM @UserTable)

						--Copy Message
						--exec Message_Copy @intMessageID, @intNextMessageID OUTPUT


						--Media Check here, instead of duplicating all the updates and inserts
						IF (EXISTS(SELECT intID FROM tblMedia WHERE intID=@intMediaID))
							BEGIN
								--Create MessageByUser record for receipient --Set status as NEW, UNREAD, and CONTAINS_ATTACHMENT
								INSERT INTO tblMessageByUser(intMessageID, intUserID, intStatus) VALUES(@intNextMessageID, @intCurrentUserID, 18)
					
								--Create MessageByMedia record for message
								INSERT INTO tblMessageByMedia(intMessageID, intMediaID) VALUES(@intNextMessageID, @intMediaID)
							END
						ELSE
							BEGIN
								--Create MessageByUser record for receipient --Set status as NEW and UNREAD
								INSERT INTO tblMessageByUser(intMessageID, intUserID, intStatus) VALUES(@intMessageID, @intCurrentUserID, 2)
							END

						--Link to inbox
						INSERT INTO tblMessageByFolder(intMessageID, intFolderID) VALUES(@intMessageID, (SELECT intFolderID FROM tblFolder f LEFT JOIN tblFolderByUser fbu ON f.intID=fbu.intFolderID WHERE fbu.intUserID=@intCurrentUserID AND f.strName='inbox'))



						---Delete Current User FROM temp table
						Delete FROM @UserTable where intUserID=@intCurrentUserID
					END
					


			END
		END
END



GO

