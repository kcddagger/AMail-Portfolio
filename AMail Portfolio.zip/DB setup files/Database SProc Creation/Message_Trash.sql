USE [amail]
GO

/****** Object:  StoredProcedure [dbo].[Message_Trash]    Script Date: 8/20/2018 12:15:02 PM ******/
DROP PROCEDURE [dbo].[Message_Trash]
GO

/****** Object:  StoredProcedure [dbo].[Message_Trash]    Script Date: 8/20/2018 12:15:02 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[Message_Trash]
@intFolderID int = NULL, --The folder the message will be moved to
@intMessageID int = NULL, -- The message that is being moved
@intUserID int = NULL --Used to make sure the user owns the message
AS
BEGIN
	SET NOCOUNT ON;

	--Get the current folder the message is located
	DECLARE @intCurrentFolderID int
		SET @intCurrentFolderID = (SELECT intFolderID FROM tblMessageByFolder WHERE intFolderID IN(
			SELECT intFolderID FROM tblFolderByUser WHERE intUserID=@intUserID) AND intMessageID=@intMessageID)

			BEGIN TRY
				--update the record to change the folder
				UPDATE tblMessageByFolder SET intFolderID=@intFolderID WHERE intMessageID=@intMessageID AND intFolderID=@intCurrentFolderID
				SELECT CONVERT(bit,1)
				RETURN
			END TRY
			BEGIN CATCH
				SELECT CONVERT(bit,0)
				RETURN
			END CATCH


END
GO

