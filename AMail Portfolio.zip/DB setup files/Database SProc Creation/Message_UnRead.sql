USE [amail]
GO

/****** Object:  StoredProcedure [dbo].[Message_UnRead]    Script Date: 8/20/2018 12:15:23 PM ******/
DROP PROCEDURE [dbo].[Message_UnRead]
GO

/****** Object:  StoredProcedure [dbo].[Message_UnRead]    Script Date: 8/20/2018 12:15:23 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Crystal Buckneberg>
-- Create date: <8-16-2018>
-- Description:	<Switches message Unread/Read status>
-- =============================================
-- Change Log:
-- By: Crystal Buckneberg
-- Change Date: 8/17/2018
-- Changed: Made it so the Unread bit is turned on or off depending on its current status.

CREATE PROCEDURE [dbo].[Message_UnRead] 
	-- Add the parameters for the stored procedure here
	@intMessageID int = NULL,
	@intUserID int = NULL
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	IF EXISTS(SELECT intMessageID FROM tblMessageByUser WHERE intMessageID = @intMessageID AND intUserID = @intUserID)
		DECLARE @intStatus int
		SET @intStatus = (SELECT intStatus FROM tblMessageByUser WHERE intMessageID = @intMessageID AND intUserID = @intUserID)

		BEGIN
			UPDATE tblMessageByUser 
			SET intStatus = CASE WHEN (2 & @intStatus) = 2 THEN intStatus-2 ELSE intStatus+2 END
			WHERE intMessageID = @intMessageID AND intUserID = @intUserID
		END
END
GO

