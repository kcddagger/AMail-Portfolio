USE [amail]
GO

/****** Object:  StoredProcedure [dbo].[Messages_Move]    Script Date: 8/20/2018 12:16:41 PM ******/
DROP PROCEDURE [dbo].[Messages_Move]
GO

/****** Object:  StoredProcedure [dbo].[Messages_Move]    Script Date: 8/20/2018 12:16:41 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Brad Mandery>
-- Create date: <8-13.2018>
-- Description:	<Bulk message move, this can be factored into the original Message_Move proc, but for now just going to functionality >
-- =============================================
CREATE PROCEDURE [dbo].[Messages_Move]  --exec Messages_Move 1,2,3,'1,5,10,15,12,48,75,9890890,2'
@intFolderToMoveTo INT = null,
@intFolderToMoveFrom INT = null,
@intUserID INT = null,
@vcMessageIDs varchar(500) 
AS
BEGIN
	SET NOCOUNT ON;

--Temp table to hold the message ids after we split them on a comma
declare @tempMessageIDS as table
(
	intID int
)

--Loop through vcMessage ID and break out each number
	while(CHARINDEX(',', @vcMessageIDs))>0
		BEGIN

			insert into @tempMessageIDS
				Select Substring(@vcMessageIDs, 0, CHARINDEX(',', @vcMessageIDs))

			set @vcMessageIDs = (Select right(@vcMessageIDs,Len(@vcMessageIDs)-CHARINDEX(',', @vcMessageIDs)))

			if(CHARINDEX(',', @vcMessageIDs)=0)
				BEGIN
					insert into @tempMessageIDS
					select @vcMessageIDs
					break;
				END
		END


		--Now that we have all the messages ids, we can loop the temp table and update the MessageByFolder table
		declare @intMessageID INT
		while(Select count(*) from @tempMessageIDS) > 0
			BEGIN
				--Set current message id
				set @intMessageID = (Select top 1 intID FROM @tempMessageIDS)
				--update the mesage by folder table
				update tblMessageByFolder set intFolderID=@intFolderToMoveTo where intMessageID=@intMessageID and intFolderID=@intFolderToMoveFrom

				--remove message id from temp table
				delete from @tempMessageIDS where intID=@intMessageID
			END
END
GO

