USE [amail]
GO

/****** Object:  StoredProcedure [dbo].[Person_S_BySearchTerm]    Script Date: 8/20/2018 12:17:05 PM ******/
DROP PROCEDURE [dbo].[Person_S_BySearchTerm]
GO

/****** Object:  StoredProcedure [dbo].[Person_S_BySearchTerm]    Script Date: 8/20/2018 12:17:05 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Brad Mandery>
-- Create date: <8-17-2018>
-- Description:	<Get a collection of names based on a search, Used for autocomplete when creating a new message... At least for now.>
-- =============================================
CREATE PROCEDURE [dbo].[Person_S_BySearchTerm]
@vcSearchTerm varchar(500) = null
AS
BEGIN
	SET NOCOUNT ON;

		if(@vcSearchTerm IS NOT NULL)
			BEGIN
				Select (strfirstName + ' ' + strlastName) as [Name] FROM tblPerson where strFirstName like '' + @vcSearchTerm + '%'
			END
END
GO

