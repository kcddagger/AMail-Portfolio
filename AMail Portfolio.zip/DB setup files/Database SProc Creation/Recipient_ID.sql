USE [amail]
GO

/****** Object:  StoredProcedure [dbo].[Recipient_ID]    Script Date: 8/20/2018 12:17:21 PM ******/
DROP PROCEDURE [dbo].[Recipient_ID]
GO

/****** Object:  StoredProcedure [dbo].[Recipient_ID]    Script Date: 8/20/2018 12:17:21 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Crystal Buckneberg>
-- Create date: <7-31-2018>
-- Description:	<Proc to get a user ID matched to a first and lastname>


-- 8-1-2018:
--Change Log---
--*************************************************
--* Adding a local variable for the user id so we can have some control on what is set back
--* Mainly if the user id can't be found, we will return a null
--*************************************************
--=============================================
CREATE PROCEDURE [dbo].[Recipient_ID]
	@strFirstName varchar(300) = NULL,
	@strLastName varchar(300) = NULL
AS
BEGIN
	SET NOCOUNT ON;

		declare @intUserID INT
			set @intUserID = null
		if(@strFirstName IS NOT NULL AND @strLastName IS NOT NULL)
		BEGIN
				--Get user ID of the recipient to use in the message address
			set @intUserID = (Select u.intID 
			FROM tblPerson p Left JOIN tblUser u on p.intID = u.intPersonID
			WHERE p.strFirstName = @strFirstName AND p.strLastName = @strLastName)

			select @intUserID as intUserID
		END
END




---exec [Recipient_ID] 'brad', 'mandedddry'
GO

