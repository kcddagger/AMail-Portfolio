USE [amail]
GO

/****** Object:  StoredProcedure [dbo].[User_S]    Script Date: 8/20/2018 12:18:36 PM ******/
DROP PROCEDURE [dbo].[User_S]
GO

/****** Object:  StoredProcedure [dbo].[User_S]    Script Date: 8/20/2018 12:18:36 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Brad Mandery>
-- Create date: <7-17-2018>
-- Description:	<Proc to get all users>
-- =============================================
Create PROCEDURE [dbo].[User_S]
AS
BEGIN
	SET NOCOUNT ON;

		Select * FROM tblPerson p Left JOIN tblUser u on p.intID=u.intPersonID
END
GO

