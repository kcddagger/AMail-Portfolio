USE [amail]
GO

/****** Object:  StoredProcedure [dbo].[User_U]    Script Date: 8/20/2018 12:18:49 PM ******/
DROP PROCEDURE [dbo].[User_U]
GO

/****** Object:  StoredProcedure [dbo].[User_U]    Script Date: 8/20/2018 12:18:49 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Brad Mandery>
-- Create date: <7-17-2018>
-- Description:	<Proc to update the user password>
-- =============================================
CREATE PROCEDURE [dbo].[User_U]
@intUserID int = null
, @strPassword varchar(255)
AS
BEGIN
	SET NOCOUNT ON;

		if(@intUserID IS NOT NULL)
			BEGIN
				update tblUser set strPassword=@strPassword where intID=@intUserID
			END
END
GO

