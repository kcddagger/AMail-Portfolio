USE [amail]
GO

/****** Object:  StoredProcedure [dbo].[registerUser]    Script Date: 8/20/2018 12:17:37 PM ******/
DROP PROCEDURE [dbo].[registerUser]
GO

/****** Object:  StoredProcedure [dbo].[registerUser]    Script Date: 8/20/2018 12:17:37 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Brad Mandery>
-- Create date: <7-16-2018>
-- Description:	<Register a new user, this proc will take in the data to populate both tables(Person and User)>
-- =============================================
--exec registerUser 'b', 'andery', '1-1-1990', 'bman', 'fast', 'bman@amail.com'
CREATE PROCEDURE [dbo].[registerUser]
@strFirstName varchar(300) = null
, @strLastName varchar(300) = null
, @dtDateOfBirth DateTime = null
, @strUserName varchar(300) = null
, @strPassword varchar(255) = null
, @strEmailAddress varchar(255) = null
AS
BEGIN
	SET NOCOUNT ON;

	declare @guid uniqueidentifier
	set @guid = NEWID()
	--First we have to create our person, as we need the person ID to be able to create a USER
	INSERT INTO tblPerson(strFirstName, strLastName, dtDateOfBirth, strGUID) Values(@strFirstName, @strLastName, @dtDateOfBirth, @guid)

	--Get personID
	declare @intPersonID int
	set @intPersonID = (Select intID FROM tblPerson where strGUID=@guid)


	INSERT INTO tblUser(strUserName, strPassword, strEmailAddress, intPersonID, intUserTypeID) values(@strUserName, @strPassword, @strEmailAddress, @intPersonID,1)

	--Link default folders
	--This will happen in a trigger on the user table AFTER INSERT

	select @guid
END
GO

