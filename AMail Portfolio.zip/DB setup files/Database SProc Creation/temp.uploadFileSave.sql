USE [amail]
GO

/****** Object:  StoredProcedure [dbo].[temp_uploadFileSave]    Script Date: 8/20/2018 12:18:18 PM ******/
DROP PROCEDURE [dbo].[temp_uploadFileSave]
GO

/****** Object:  StoredProcedure [dbo].[temp_uploadFileSave]    Script Date: 8/20/2018 12:18:18 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Brad Mandery>
-- Edited by:	<Crystal Buckneberg>
-- Create date: <Create Date,,>
-- Edit date:	<8/9/2018 10:10:12 AM>
-- Description:	<Inserts the media file into the tblMedia and returns the intID as intMediaID>
-- =============================================
CREATE PROCEDURE [dbo].[temp_uploadFileSave]
@strName varchar(255) = null
, @strContentType varchar(255) = null
, @strExtension varchar(10) = null
, @binMedia varbinary(max) = null
AS
BEGIN
	SET NOCOUNT ON;

	IF(@binMedia IS NOT NULL)
		BEGIN
		DECLARE @guid uniqueidentifier;
			SET @guid = NEWID();

			INSERT INTO tblMedia(guid, strName, strContentType, strExtension, binMedia)
				VALUES(@guid, @strName, @strContentType, @strExtension, @binMedia)
			
			DECLARE @intMediaID int;
			SET @intMediaID = (SELECT intID FROM tblMedia WHERE guid=@guid)

			SELECT @intMediaID AS intMediaID
		END
END
GO

