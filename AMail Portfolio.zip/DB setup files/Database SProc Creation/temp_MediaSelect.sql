USE [amail]
GO

/****** Object:  StoredProcedure [dbo].[temp_MediaSelect]    Script Date: 8/20/2018 12:17:55 PM ******/
DROP PROCEDURE [dbo].[temp_MediaSelect]
GO

/****** Object:  StoredProcedure [dbo].[temp_MediaSelect]    Script Date: 8/20/2018 12:17:55 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[temp_MediaSelect]
@intMediaID INT = null
AS
BEGIN
	SET NOCOUNT ON;

		Select * from tblMedia where intID=@intMediaID
END
GO

