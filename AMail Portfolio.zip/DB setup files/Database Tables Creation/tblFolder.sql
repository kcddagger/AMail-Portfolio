USE [amail]
GO

ALTER TABLE [dbo].[tblFolder] DROP CONSTRAINT [DF_tblFolder_dtCreated]
GO

ALTER TABLE [dbo].[tblFolder] DROP CONSTRAINT [DF_tblFolder_dtUpdated]
GO

/****** Object:  Table [dbo].[tblFolder]    Script Date: 8/20/2018 12:07:24 PM ******/
DROP TABLE [dbo].[tblFolder]
GO

/****** Object:  Table [dbo].[tblFolder]    Script Date: 8/20/2018 12:07:24 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[tblFolder](
	[intID] [int] IDENTITY(1,1) NOT NULL,
	[strName] [varchar](255) NOT NULL,
	[bitPermanent] [bit] NOT NULL,
	[intParentID] [int] NULL,
	[strGUID] [uniqueidentifier] NOT NULL,
	[dtUpdated] [datetime] NOT NULL,
	[dtCreated] [datetime] NOT NULL,
 CONSTRAINT [PK_tblFolder] PRIMARY KEY CLUSTERED 
(
	[intID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[tblFolder] ADD  CONSTRAINT [DF_tblFolder_dtUpdated]  DEFAULT (getdate()) FOR [dtUpdated]
GO

ALTER TABLE [dbo].[tblFolder] ADD  CONSTRAINT [DF_tblFolder_dtCreated]  DEFAULT (getdate()) FOR [dtCreated]
GO

