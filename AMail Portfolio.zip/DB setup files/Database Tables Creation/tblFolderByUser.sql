USE [amail]
GO

ALTER TABLE [dbo].[tblFolderByUser] DROP CONSTRAINT [FK_tblFolderByUser_tblUser]
GO

ALTER TABLE [dbo].[tblFolderByUser] DROP CONSTRAINT [FK_tblFolderByUser_tblFolder]
GO

/****** Object:  Table [dbo].[tblFolderByUser]    Script Date: 8/20/2018 12:07:55 PM ******/
DROP TABLE [dbo].[tblFolderByUser]
GO

/****** Object:  Table [dbo].[tblFolderByUser]    Script Date: 8/20/2018 12:07:55 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[tblFolderByUser](
	[intFolderID] [int] NOT NULL,
	[intUserID] [int] NOT NULL,
	[intType] [int] NOT NULL
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[tblFolderByUser]  WITH CHECK ADD  CONSTRAINT [FK_tblFolderByUser_tblFolder] FOREIGN KEY([intFolderID])
REFERENCES [dbo].[tblFolder] ([intID])
ON DELETE CASCADE
GO

ALTER TABLE [dbo].[tblFolderByUser] CHECK CONSTRAINT [FK_tblFolderByUser_tblFolder]
GO

ALTER TABLE [dbo].[tblFolderByUser]  WITH CHECK ADD  CONSTRAINT [FK_tblFolderByUser_tblUser] FOREIGN KEY([intUserID])
REFERENCES [dbo].[tblUser] ([intID])
ON DELETE CASCADE
GO

ALTER TABLE [dbo].[tblFolderByUser] CHECK CONSTRAINT [FK_tblFolderByUser_tblUser]
GO

