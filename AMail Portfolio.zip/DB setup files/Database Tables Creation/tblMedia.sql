USE [amail]
GO

ALTER TABLE [dbo].[tblMedia] DROP CONSTRAINT [DF_tblMedia_dtCreated]
GO

ALTER TABLE [dbo].[tblMedia] DROP CONSTRAINT [DF_tblMedia_dtUpdated]
GO

ALTER TABLE [dbo].[tblMedia] DROP CONSTRAINT [DF_tblMedia_guid]
GO

/****** Object:  Table [dbo].[tblMedia]    Script Date: 8/20/2018 12:08:11 PM ******/
DROP TABLE [dbo].[tblMedia]
GO

/****** Object:  Table [dbo].[tblMedia]    Script Date: 8/20/2018 12:08:11 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[tblMedia](
	[intID] [int] IDENTITY(1,1) NOT NULL,
	[guid] [uniqueidentifier] ROWGUIDCOL  NOT NULL,
	[strName] [varchar](255) NOT NULL,
	[strContentType] [varchar](255) NOT NULL,
	[strExtension] [varchar](10) NOT NULL,
	[binMedia] [varbinary](max) FILESTREAM  NOT NULL,
	[dtUpdated] [datetime] NOT NULL,
	[dtCreated] [datetime] NOT NULL,
 CONSTRAINT [UQ__tblMedia__497F6CB5210D87FD] UNIQUE NONCLUSTERED 
(
	[guid] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] FILESTREAM_ON [Attachments]
GO

ALTER TABLE [dbo].[tblMedia] ADD  CONSTRAINT [DF_tblMedia_guid]  DEFAULT (newid()) FOR [guid]
GO

ALTER TABLE [dbo].[tblMedia] ADD  CONSTRAINT [DF_tblMedia_dtUpdated]  DEFAULT (getdate()) FOR [dtUpdated]
GO

ALTER TABLE [dbo].[tblMedia] ADD  CONSTRAINT [DF_tblMedia_dtCreated]  DEFAULT (getdate()) FOR [dtCreated]
GO

