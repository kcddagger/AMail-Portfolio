USE [amail]
GO

ALTER TABLE [dbo].[tblMessage] DROP CONSTRAINT [FK_tblMessage_tblMessage]
GO

ALTER TABLE [dbo].[tblMessage] DROP CONSTRAINT [DF_tblMessage_dtCreated]
GO

ALTER TABLE [dbo].[tblMessage] DROP CONSTRAINT [DF_tblMessage_dtUpdated]
GO

/****** Object:  Table [dbo].[tblMessage]    Script Date: 8/20/2018 12:08:28 PM ******/
DROP TABLE [dbo].[tblMessage]
GO

/****** Object:  Table [dbo].[tblMessage]    Script Date: 8/20/2018 12:08:28 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[tblMessage](
	[intID] [int] IDENTITY(1,1) NOT NULL,
	[strMessageBody] [varchar](max) NOT NULL,
	[strMessageSubject] [varchar](max) NULL,
	[strGUID] [uniqueidentifier] NOT NULL,
	[dtUpdated] [datetime] NOT NULL,
	[dtCreated] [datetime] NOT NULL,
 CONSTRAINT [PK_tblMessage] PRIMARY KEY CLUSTERED 
(
	[intID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

ALTER TABLE [dbo].[tblMessage] ADD  CONSTRAINT [DF_tblMessage_dtUpdated]  DEFAULT (getdate()) FOR [dtUpdated]
GO

ALTER TABLE [dbo].[tblMessage] ADD  CONSTRAINT [DF_tblMessage_dtCreated]  DEFAULT (getdate()) FOR [dtCreated]
GO

ALTER TABLE [dbo].[tblMessage]  WITH CHECK ADD  CONSTRAINT [FK_tblMessage_tblMessage] FOREIGN KEY([intID])
REFERENCES [dbo].[tblMessage] ([intID])
GO

ALTER TABLE [dbo].[tblMessage] CHECK CONSTRAINT [FK_tblMessage_tblMessage]
GO

