USE [amail]
GO

/****** Object:  Table [dbo].[tblMessageByFolder]    Script Date: 8/20/2018 12:09:00 PM ******/
DROP TABLE [dbo].[tblMessageByFolder]
GO

/****** Object:  Table [dbo].[tblMessageByFolder]    Script Date: 8/20/2018 12:09:00 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[tblMessageByFolder](
	[intMessageID] [int] NOT NULL,
	[intFolderID] [int] NOT NULL
) ON [PRIMARY]
GO

