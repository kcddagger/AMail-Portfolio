USE [amail]
GO

/****** Object:  Table [dbo].[tblMessageByMedia]    Script Date: 8/20/2018 12:09:17 PM ******/
DROP TABLE [dbo].[tblMessageByMedia]
GO

/****** Object:  Table [dbo].[tblMessageByMedia]    Script Date: 8/20/2018 12:09:17 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[tblMessageByMedia](
	[intMessageID] [int] NOT NULL,
	[intMediaID] [int] NOT NULL
) ON [PRIMARY]
GO

