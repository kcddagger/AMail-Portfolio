USE [amail]
GO

ALTER TABLE [dbo].[tblMessageByUser] DROP CONSTRAINT [FK_tblMessageByUser_tblUser]
GO

ALTER TABLE [dbo].[tblMessageByUser] DROP CONSTRAINT [FK_tblMessageByUser_tblMessage]
GO

ALTER TABLE [dbo].[tblMessageByUser] DROP CONSTRAINT [DF_tblMessageByUser_dtCreated]
GO

ALTER TABLE [dbo].[tblMessageByUser] DROP CONSTRAINT [DF_tblMessageByUser_dtUpdated]
GO

/****** Object:  Table [dbo].[tblMessageByUser]    Script Date: 8/20/2018 12:09:39 PM ******/
DROP TABLE [dbo].[tblMessageByUser]
GO

/****** Object:  Table [dbo].[tblMessageByUser]    Script Date: 8/20/2018 12:09:39 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[tblMessageByUser](
	[intMessageID] [int] NOT NULL,
	[intUserID] [int] NOT NULL,
	[intStatus] [int] NOT NULL,
	[dtUpdated] [datetime] NOT NULL,
	[dtCreated] [datetime] NOT NULL,
	[dtArchived] [datetime] NULL
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[tblMessageByUser] ADD  CONSTRAINT [DF_tblMessageByUser_dtUpdated]  DEFAULT (getdate()) FOR [dtUpdated]
GO

ALTER TABLE [dbo].[tblMessageByUser] ADD  CONSTRAINT [DF_tblMessageByUser_dtCreated]  DEFAULT (getdate()) FOR [dtCreated]
GO

ALTER TABLE [dbo].[tblMessageByUser]  WITH CHECK ADD  CONSTRAINT [FK_tblMessageByUser_tblMessage] FOREIGN KEY([intMessageID])
REFERENCES [dbo].[tblMessage] ([intID])
GO

ALTER TABLE [dbo].[tblMessageByUser] CHECK CONSTRAINT [FK_tblMessageByUser_tblMessage]
GO

ALTER TABLE [dbo].[tblMessageByUser]  WITH CHECK ADD  CONSTRAINT [FK_tblMessageByUser_tblUser] FOREIGN KEY([intUserID])
REFERENCES [dbo].[tblUser] ([intID])
GO

ALTER TABLE [dbo].[tblMessageByUser] CHECK CONSTRAINT [FK_tblMessageByUser_tblUser]
GO

