USE [amail]
GO

ALTER TABLE [dbo].[tblPerson] DROP CONSTRAINT [DF_tblPerson_dtUpdated]
GO

ALTER TABLE [dbo].[tblPerson] DROP CONSTRAINT [DF_tblPerson_dtCreated]
GO

/****** Object:  Table [dbo].[tblPerson]    Script Date: 8/20/2018 12:09:54 PM ******/
DROP TABLE [dbo].[tblPerson]
GO

/****** Object:  Table [dbo].[tblPerson]    Script Date: 8/20/2018 12:09:54 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[tblPerson](
	[intID] [int] IDENTITY(1,1) NOT NULL,
	[strFirstName] [varchar](300) NOT NULL,
	[strLastName] [varchar](300) NOT NULL,
	[dtDateOfBirth] [datetime] NULL,
	[strGUID] [uniqueidentifier] NOT NULL,
	[dtCreated] [datetime] NOT NULL,
	[dtUpdated] [datetime] NOT NULL,
 CONSTRAINT [PK_tblPerson] PRIMARY KEY CLUSTERED 
(
	[intID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[tblPerson] ADD  CONSTRAINT [DF_tblPerson_dtCreated]  DEFAULT (getdate()) FOR [dtCreated]
GO

ALTER TABLE [dbo].[tblPerson] ADD  CONSTRAINT [DF_tblPerson_dtUpdated]  DEFAULT (getdate()) FOR [dtUpdated]
GO

