USE [amail]
GO

ALTER TABLE [dbo].[tblUser] DROP CONSTRAINT [FK_tblUser_tblPerson]
GO

ALTER TABLE [dbo].[tblUser] DROP CONSTRAINT [DF_tblUser_dtUpdated]
GO

ALTER TABLE [dbo].[tblUser] DROP CONSTRAINT [DF_tblUser_dtCreated]
GO

ALTER TABLE [dbo].[tblUser] DROP CONSTRAINT [DF_tblUser_intLoginCount]
GO

/****** Object:  Table [dbo].[tblUser]    Script Date: 8/20/2018 12:10:07 PM ******/
DROP TABLE [dbo].[tblUser]
GO

/****** Object:  Table [dbo].[tblUser]    Script Date: 8/20/2018 12:10:07 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[tblUser](
	[intID] [int] IDENTITY(1,1) NOT NULL,
	[intPersonID] [int] NULL,
	[strUserName] [varchar](300) NOT NULL,
	[strPassword] [varchar](255) NOT NULL,
	[strEmailAddress] [varchar](255) NOT NULL,
	[intLoginCount] [int] NOT NULL,
	[intUserTypeID] [int] NOT NULL,
	[dtCreated] [datetime] NOT NULL,
	[dtUpdated] [datetime] NOT NULL,
 CONSTRAINT [PK_tblUser] PRIMARY KEY CLUSTERED 
(
	[intID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[tblUser] ADD  CONSTRAINT [DF_tblUser_intLoginCount]  DEFAULT ((0)) FOR [intLoginCount]
GO

ALTER TABLE [dbo].[tblUser] ADD  CONSTRAINT [DF_tblUser_dtCreated]  DEFAULT (getdate()) FOR [dtCreated]
GO

ALTER TABLE [dbo].[tblUser] ADD  CONSTRAINT [DF_tblUser_dtUpdated]  DEFAULT (getdate()) FOR [dtUpdated]
GO

ALTER TABLE [dbo].[tblUser]  WITH CHECK ADD  CONSTRAINT [FK_tblUser_tblPerson] FOREIGN KEY([intPersonID])
REFERENCES [dbo].[tblPerson] ([intID])
ON UPDATE CASCADE
ON DELETE CASCADE
GO

ALTER TABLE [dbo].[tblUser] CHECK CONSTRAINT [FK_tblUser_tblPerson]
GO

