USE [amail]
GO

/****** Object:  Table [dbo].[tblUserType]    Script Date: 8/20/2018 12:10:23 PM ******/
DROP TABLE [dbo].[tblUserType]
GO

/****** Object:  Table [dbo].[tblUserType]    Script Date: 8/20/2018 12:10:23 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[tblUserType](
	[intITypeD] [int] NOT NULL,
	[strType] [varchar](50) NOT NULL
) ON [PRIMARY]
GO

